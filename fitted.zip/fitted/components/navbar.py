"""Sticky top navigation: logo, main links, bag and account menu."""

from __future__ import annotations

import streamlit as st

from utils import session


def _link(col, page: str, label: str, current: str, **kw) -> None:
    """Page link; the current page gets the "nav-on-" key -> black text + underline."""
    state = "on" if page == current else "off"
    with col.container(key=f"nav-{state}-{page}"):
        st.page_link(session.PAGES[page], label=label, **kw)


def render(current: str = "") -> None:
    user = session.current_user()
    if not user:
        return
    first = user["name"].split()[0]
    bag = session.cart_count()
    favs = len(session.favorites())

    with st.container(key="navbar"):
        cols = st.columns([2.3, 0.8, 0.85, 1.25, 1.15, 0.8, 1.25], vertical_alignment="center", gap="small")
        cols[0].markdown('<span class="ft-logo">FITTED</span>', unsafe_allow_html=True)
        _link(cols[1], "home", "Home", current)
        _link(cols[2], "closet", "Closet", current)
        _link(cols[3], "profile", "My profile", current)
        _link(cols[4], "favorites", f"Favorites{f' ({favs})' if favs else ''}", current)
        _link(cols[5], "cart", f"Bag ({bag})" if bag else "Bag", current, icon=":material/shopping_bag:",
              help="Shopping bag")
        with cols[6].popover(first, icon=":material/person:"):
            st.markdown(f"**{user['name']}**  \n<span class='ft-small'>{user['email']}</span>", unsafe_allow_html=True)
            st.page_link(session.PAGES["profile"], label="Profile & settings", icon=":material/settings:")
            st.page_link(session.PAGES["tryon"], label="Virtual try-on", icon=":material/auto_awesome:")
            if st.button("Log out", key="nav-logout", type="tertiary", icon=":material/logout:"):
                session.logout()
                st.rerun()
