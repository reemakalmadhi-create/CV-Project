"""Centered empty state with a Lottie animation and an optional call to action."""

from __future__ import annotations

import html
from typing import Optional

import streamlit as st

from components.animations import lottie
from utils import session


def empty_state(animation: str, title: str, text: str = "",
                cta_label: Optional[str] = None, cta_page: Optional[str] = None, key: str = "empty") -> None:
    _, mid, _ = st.columns([1, 1.4, 1])
    with mid:
        lottie(animation, height=170)
        st.markdown(
            f'<div class="ft-empty"><h3>{html.escape(title)}</h3><p>{html.escape(text)}</p></div>',
            unsafe_allow_html=True,
        )
        if cta_label and cta_page:
            if st.button(cta_label, type="primary", width="stretch", key=f"{key}-cta"):
                session.go(cta_page)
