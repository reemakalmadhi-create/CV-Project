"""Shared header for the login and sign-up pages (centered form, no side picture)."""

from __future__ import annotations

import streamlit as st


def logo() -> None:
    st.markdown('<p class="ft-logo" style="display:block;text-align:center;margin:0 0 2rem">FITTED</p>',
                unsafe_allow_html=True)
