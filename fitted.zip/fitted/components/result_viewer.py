"""Try-on result area.

`render(result_image=None, ...)` draws an empty placeholder frame, a disabled
download button and the "Try another outfit" action. As soon as the future
IDM-VTON inference returns a real image, pass it in and the same component
shows it, a before/after comparison slider and an enabled download.
"""

from __future__ import annotations

import base64
import io
from typing import Optional

import streamlit as st
from PIL import Image

from components.animations import html_frame
from utils import session


def _data_url(image: Image.Image, fmt: str = "JPEG") -> str:
    buf = io.BytesIO()
    image.convert("RGB").save(buf, format=fmt, quality=90)
    return f"data:image/{fmt.lower()};base64," + base64.b64encode(buf.getvalue()).decode()


def compare_slider(before: Image.Image, after: Image.Image, height: int = 620) -> None:
    """Drag the handle to compare the original photo with the try-on result."""
    html = f"""
<div id="c" style="position:relative;height:{height - 8}px;background:#F3F3F3;border:1px solid #E5E5E5;overflow:hidden;
     font:600 10px Manrope,system-ui,sans-serif;letter-spacing:.2em;text-transform:uppercase;color:#777;user-select:none">
  <img src="{_data_url(before)}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain">
  <img id="a" src="{_data_url(after)}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain;clip-path:inset(0 50% 0 0)">
  <div id="h" style="position:absolute;top:0;bottom:0;left:50%;width:1px;background:#111"></div>
  <div id="k" style="position:absolute;top:50%;left:50%;width:38px;height:38px;margin:-19px;border-radius:50%;background:#111;color:#fff;
       display:flex;align-items:center;justify-content:center;font-size:14px;letter-spacing:0;cursor:ew-resize">&#8596;</div>
  <span style="position:absolute;left:12px;top:10px">After</span><span style="position:absolute;right:12px;top:10px">Before</span>
  <input id="r" type="range" min="0" max="100" value="50" aria-label="Before / after"
         style="position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:ew-resize;margin:0">
</div>
<script>
const r=document.getElementById('r'),a=document.getElementById('a'),h=document.getElementById('h'),k=document.getElementById('k');
r.addEventListener('input',()=>{{const v=r.value;a.style.clipPath=`inset(0 ${{100-v}}% 0 0)`;h.style.left=k.style.left=v+'%';}});
</script>"""
    html_frame(html, height)


def render(
    result_image: Optional[Image.Image] = None,
    person_image: Optional[Image.Image] = None,
    product: Optional[dict] = None,
) -> None:
    has_result = result_image is not None
    if has_result and person_image is not None:
        tab_result, tab_compare = st.tabs(["Result", "Before / After"])
        with tab_result:
            st.image(result_image, width="stretch")
        with tab_compare:
            compare_slider(person_image, result_image)
    else:
        st.markdown(
            "<div class='ft-frame'><span class='ft-frame-label'>Generated look</span>"
            "<div class='ft-frame-empty'><strong>No try-on result yet</strong>"
            "The generated image will appear here, with a before / after comparison,<br>"
            "once IDM-VTON is connected.</div></div>",
            unsafe_allow_html=True,
        )

    data, name = b"", "fitted-tryon.png"
    if has_result:
        buf = io.BytesIO()
        result_image.save(buf, format="PNG")
        data = buf.getvalue()
        if product:
            name = f"fitted-tryon-{product['id']}.png"

    a, b = st.columns(2)
    a.download_button("Download result", data=data, file_name=name, mime="image/png",
                      disabled=not has_result, icon=":material/download:", width="stretch",
                      help=None if has_result else "Available once a real try-on result exists")
    if b.button("Try another outfit", icon=":material/checkroom:", width="stretch", key="try-another"):
        st.session_state.tryon_outcome = None
        session.go("closet")
