"""Product card with CSS 3D depth (tilt + glare wired up in assets/js/fx.js)."""

from __future__ import annotations

import html

import streamlit as st

from utils import session
from utils.catalog import format_sar


def swatches(product: dict, large: bool = False) -> str:
    cls = "ft-swatch lg" if large else "ft-swatch"
    return "".join(
        f'<span class="{cls}" title="{html.escape(c["name"])}" style="background:{html.escape(c["hex"])}"></span>'
        for c in product.get("colors", [])
    )


def media_html(product: dict, badge: str = "") -> str:
    badge_html = f'<span class="ft-badge">{html.escape(badge)}</span>' if badge else ""
    return (
        f'<div class="ft-card-media">{badge_html}'
        f'<img src="{html.escape(product["image"])}" alt="{html.escape(product["name"])}" loading="lazy">'
        f'<span class="ft-card-glare"></span></div>'
    )


def card_text(product: dict) -> str:
    """Name, price and swatches. The bottom padding keeps the buttons from
    overlapping the price (Streamlit pulls the next element up ~1rem)."""
    return (
        '<div style="padding-bottom:20px">'
        f'<div class="ft-card-name">{html.escape(product["name"])}</div>'
        f'<div class="ft-card-row"><span class="ft-card-price">{format_sar(product["price_sar"])}</span>'
        f'<span class="ft-swatches">{swatches(product)}</span></div></div>'
    )


def render(product: dict, prefix: str = "grid", show_tryon: bool = False) -> None:
    pid = product["id"]
    fav = session.is_favorite(pid)
    with st.container(key=f"card-{prefix}-{pid}"):
        st.markdown(
            media_html(product, product.get("category", ""))
            + card_text(product),
            unsafe_allow_html=True,
        )
        if show_tryon:
            a, b, c = st.columns([1, 1, 0.55], gap="small")
        else:
            a, c = st.columns([1, 0.4], gap="small")
            b = None
        if a.button("View", key=f"{prefix}-view-{pid}", width="stretch"):
            session.open_product(pid)
        if b is not None and b.button("Try on", key=f"{prefix}-try-{pid}", type="primary", width="stretch"):
            session.start_tryon(pid)
        if c.button("", key=f"{prefix}-fav-{pid}", icon=":material/favorite:" if fav else ":material/favorite_border:",
                    help="Remove from favorites" if fav else "Save to favorites", width="stretch"):
            now = session.toggle_favorite(pid)
            session.flash("Saved to favorites" if now else "Removed from favorites", ":material/favorite:" if now else ":material/check_circle:")
            st.rerun()


def grid(products: list[dict], prefix: str = "grid", columns: int = 4, show_tryon: bool = False) -> None:
    for start in range(0, len(products), columns):
        cols = st.columns(columns, gap="medium")
        for col, product in zip(cols, products[start:start + columns]):
            with col:
                render(product, prefix, show_tryon)
