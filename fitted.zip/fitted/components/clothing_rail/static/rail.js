/* FITTED clothing rail — plain-JS port of the <ClothingRailHero/> React
   component (photo mode), packaged as a Streamlit custom component with no
   build step.

   Streamlit -> component  args: items, eyebrow, heading, caption, autoplay, interval, hint
   component -> Streamlit  value: { type: "open", id, nonce }   (nonce is unique per click)
*/
(function () {
  "use strict";

  // ---------------------------------------------------------------- constants (from the original)
  var VB_W = 200, VB_H = 310, ASPECT = VB_W / VB_H, HOOK_TOP = 4, RAIL_R = 4.6;
  var REST = -70, PERSPECTIVE = 1100, GAP = 0.035, MAX_H = 400, MIN_WIDE_H = 200, CAROUSEL_H = 340;

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function footprint(h, angle, sideW) {
    if (sideW === undefined) sideW = 0.4;
    var e = clamp(1 - angle / REST, 0, 1), ease = e * e * (3 - 2 * e);
    return h * ASPECT * (sideW + (0.94 - sideW) * ease);
  }
  function lambert(angle) {
    var r = angle * Math.PI / 180;
    return 0.66 + 0.34 * Math.max(0, Math.sin(r) * 0.42 + Math.cos(r) * 0.91);
  }
  function el(tag, cls, attrs) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (attrs) for (var k in attrs) n.setAttribute(k, attrs[k]);
    return n;
  }

  // ---------------------------------------------------------------- Streamlit protocol
  function post(type, data) {
    var msg = { isStreamlitMessage: true, type: type };
    for (var k in data || {}) msg[k] = data[k];
    window.parent.postMessage(msg, "*");
  }
  var nonceBase = Date.now(), nonceCount = 0;
  function emit(type, id) { post("streamlit:setComponentValue", { value: { type: type, id: id, nonce: nonceBase + (++nonceCount) }, dataType: "json" }); }
  var lastHeight = 0;
  function viewportMin() {
    if (!props || !props.fillViewport) return 0;
    try { return Math.max(0, window.parent.innerHeight - (props.viewportOffset || 96)); } catch (e) { return 0; }
  }
  function reportHeight() {
    var rootEl = document.getElementById("rail-root");
    var min = viewportMin();
    rootEl.style.minHeight = min ? min + "px" : "";
    var h = Math.ceil(rootEl.getBoundingClientRect().height);
    if (detail) h = Math.max(h, Math.ceil(detail.el.querySelector(".dlg-grid").getBoundingClientRect().height + 96));
    if (Math.abs(h - lastHeight) > 1) { lastHeight = h; post("streamlit:setFrameHeight", { height: h }); }
  }

  // ---------------------------------------------------------------- state
  var root = document.getElementById("rail-root");
  var reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var props = null, items = [], count = 0, sideWidths = [];
  var refs = null;            // per-item DOM refs
  var size = { width: 0, h: 300, carousel: false };
  var lastShown = 0, active = null, focusIndex = 0, carouselIndex = 0, playing = false, timer = 0, brushed = false;
  var stageEl, barEl, dotsEl, capEl;
  var sim = emptySim();
  var pointer = { id: -1, index: -1, x: 0, y: 0, moved: false, kind: "", swipe: 0, lastX: 0, lastT: 0, v: 0 };
  var pendingOpen = -1;

  function emptySim() {
    return { x: [], vx: [], tx: [], turn: [], vturn: [], tturn: [], swing: [], vswing: [], tag: [], vtag: [], drag: -1, grab: 0, free: 0, last: 0, raf: 0 };
  }

  // ---------------------------------------------------------------- build DOM
  function build() {
    cancelAnimationFrame(sim.raf);
    sim = emptySim();
    root.innerHTML = "";
    root.appendChild(el("div", "rail-bg", { "aria-hidden": "true" }));

    if (props.eyebrow || props.heading) {
      var head = el("header", "rail-head");
      if (props.eyebrow) { var p = el("p", "rail-eyebrow"); p.textContent = props.eyebrow; head.appendChild(p); }
      if (props.heading) { var h2 = el("h2", "rail-heading"); h2.textContent = props.heading; head.appendChild(h2); }
      root.appendChild(head);
    }

    stageEl = el("div", "stage", { role: "group", "aria-label": props.heading || "Clothing rail" });
    barEl = el("div", "bar", { "aria-hidden": "true" });
    barEl.innerHTML = '<div class="bar-shadow"></div><div class="bar-metal"></div><div class="bar-brush"></div><div class="bar-end l"></div><div class="bar-end r"></div>';
    stageEl.appendChild(barEl);

    refs = items.map(function (item, i) {
      var r = {};
      var slot = r.slot = el("button", "slot", { type: "button", "data-garment": i, "aria-label": item.name + (item.tag ? ", " + item.tag : ""), "aria-describedby": "rail-caption", "aria-pressed": "false", tabindex: i === 0 ? "0" : "-1" });
      var swing = r.swing = el("span", "swing");
      swing.style.transformOrigin = "50% " + (HOOK_TOP / VB_H * 100) + "%";

      var shWrap = r.shadowWrap = el("span", "shadow-wrap", { "aria-hidden": "true" });
      var sh = r.shadow = el("span", "shadow");
      var mask = 'url("' + item.image + '") top center / contain no-repeat';
      sh.style.webkitMask = mask; sh.style.mask = mask;
      shWrap.appendChild(sh); swing.appendChild(shWrap);

      if (item.sideImage) {
        var side = r.side = el("span", "layer", { "data-face": "side" });
        side.style.transform = "perspective(" + PERSPECTIVE + "px) rotateY(0deg)";
        side.appendChild(photo(item.sideImage));
        swing.appendChild(side);
      }

      var turn = r.turn = el("span", "turn");
      turn.style.transform = "perspective(" + PERSPECTIVE + "px) rotateY(" + REST + "deg)";
      turn.style.opacity = item.sideImage ? "0" : "1";
      ["front", "back"].forEach(function (face) {
        var f = el("span", "face " + face, { "data-face": face });
        var drape = el("span", "drape");
        var src = face === "back" ? (item.backImage || item.image) : item.image;
        drape.appendChild(photo(src));
        var shade = el("span", "shade");
        var m = 'url("' + src + '") top center / contain no-repeat';
        shade.style.webkitMask = m; shade.style.mask = m;
        drape.appendChild(shade);
        if (face === "front") { r.drape = drape; r.shade = shade; }
        f.appendChild(drape);
        turn.appendChild(f);
      });
      swing.appendChild(turn);

      if (item.tag) {
        var tag = r.tag = el("span", "tag", { "aria-hidden": "true" });
        tag.innerHTML = '<span class="tag-string"></span>';
        var card = el("span", "tag-card"); card.textContent = item.tag; tag.appendChild(card);
        swing.appendChild(tag);
      }
      slot.appendChild(swing);

      slot.addEventListener("focus", function () { focusIndex = i; if (pointer.id < 0) { stop(); choose(i); } });
      slot.addEventListener("click", function (ev) {
        var pending = pendingOpen; pendingOpen = -1;
        if (ev.detail === 0 || pending === i) open(i);
      });
      stageEl.appendChild(slot);
      return r;
    });
    root.appendChild(stageEl);

    dotsEl = el("div", "dots", { role: "group", "aria-label": "Show" });
    root.appendChild(dotsEl);
    capEl = el("div", "caption");
    root.appendChild(capEl);

    stageEl.addEventListener("pointermove", onPointerMove);
    stageEl.addEventListener("pointerdown", onPointerDown);
    stageEl.addEventListener("pointerup", function (e) { finishPointer(e, false); });
    stageEl.addEventListener("pointercancel", function (e) { finishPointer(e, true); });
    stageEl.addEventListener("pointerleave", function (e) {
      if (e.pointerType === "mouse" && pointer.id < 0 && !size.carousel && !(document.activeElement && document.activeElement.matches && document.activeElement.matches(".slot:focus-visible"))) choose(null);
    });
    stageEl.addEventListener("keydown", onKeyDown);

    active = null; focusIndex = 0; carouselIndex = 0; lastShown = 0; brushed = false;
    measure();
    renderCaption();
  }

  function photo(src) {
    var img = el("img", "photo", { src: src, alt: "", draggable: "false", decoding: "async" });
    img.addEventListener("load", reportHeight);
    return img;
  }

  // ---------------------------------------------------------------- layout
  function measure() {
    var width = stageEl.clientWidth || root.clientWidth || window.innerWidth;
    var avgSide = sideWidths.reduce(function (s, w) { return s + w; }, 0) / Math.max(1, sideWidths.length);
    var restK = footprint(1, REST, avgSide) + GAP, activeK = footprint(1, 0, avgSide) + GAP;
    var fit = (width - 24) / (count * restK + (activeK - restK));
    var carousel = fit < MIN_WIDE_H;
    var h = Math.round(carousel ? Math.min(CAROUSEL_H, Math.max(220, width * 0.86)) : Math.min(MAX_H, fit));
    var changed = Math.abs(size.width - width) >= 0.5 || size.carousel !== carousel || Math.abs(size.h - h) >= 0.5;
    size = { width: width, h: h, carousel: carousel };
    if (changed || !sim.x.length) layout();
  }

  function layout() {
    var h = size.h, boxW = h * ASPECT;
    var railY = Math.round(h * 0.07) + 10;
    var railR = Math.max(3, Math.round(RAIL_R / VB_H * h * 10) / 10);
    stageEl.style.height = Math.round(railY + h + h * 0.05 + 12) + "px";
    barEl.style.top = (railY - railR) + "px";
    barEl.style.height = (railR * 2) + "px";
    barEl.firstChild.style.top = (railR * 2 + 1) + "px";
    refs.forEach(function (r, i) {
      r.slot.style.top = (railY - HOOK_TOP / VB_H * h) + "px";
      r.slot.style.width = boxW + "px";
      r.slot.style.height = h + "px";
      r.shadowWrap.style.filter = "blur(" + Math.max(3, h * 0.022).toFixed(1) + "px)";
      if (r.tag) r.tag.style.top = (32 / VB_H * h) + "px";
    });
    renderDots();
    retarget(true);
    if (!brushed && !reduced) {
      brushed = true;
      items.forEach(function (_, i) { setTimeout(function () { impulse(i, 46 - i * 2.5); }, 120 + i * 55); });
    }
    reportHeight();
  }

  function targets(h, width, carousel, front) {
    var feet = items.map(function (_, i) { return footprint(h, i === front ? 0 : REST, sideWidths[i]) + h * GAP; });
    if (carousel) {
      var c = front === null ? 0 : front, xs = feet.map(function () { return 0; });
      xs[c] = width / 2;
      for (var i = c + 1; i < feet.length; i++) xs[i] = xs[i - 1] + (feet[i - 1] + feet[i]) / 2;
      for (var j = c - 1; j >= 0; j--) xs[j] = xs[j + 1] - (feet[j + 1] + feet[j]) / 2;
      return xs;
    }
    var total = feet.reduce(function (s, f) { return s + f; }, 0), cursor = (width - total) / 2;
    return feet.map(function (f) { var x = cursor + f / 2; cursor += f; return x; });
  }

  function retarget(force) {
    var front = size.carousel ? (active === null ? carouselIndex : active) : active;
    var xs = targets(size.h, size.width, size.carousel, front);
    var fresh = sim.x.length !== count;
    for (var i = 0; i < count; i++) {
      sim.tx[i] = xs[i] + (size.carousel ? pointer.swipe : 0);
      sim.tturn[i] = i === front ? 0 : REST;
      if (fresh || reduced) {
        sim.x[i] = sim.tx[i]; sim.vx[i] = 0; sim.turn[i] = sim.tturn[i]; sim.vturn[i] = 0;
        sim.swing[i] = sim.swing[i] || 0; sim.vswing[i] = sim.vswing[i] || 0; sim.tag[i] = 0; sim.vtag[i] = 0;
      }
    }
    if (fresh || force) for (var k = 0; k < count; k++) paint(k);
    refs.forEach(function (r, i) {
      var on = active === i;
      r.slot.setAttribute("aria-pressed", on ? "true" : "false");
      r.slot.style.zIndex = on ? 30 : 10 + i;
      r.slot.tabIndex = i === (active === null ? focusIndex : active) ? 0 : -1;
    });
    kick();
  }

  // ---------------------------------------------------------------- physics (ported verbatim)
  function paint(i) {
    var r = refs[i]; if (!r) return;
    var h = size.h, w = h * ASPECT;
    var angle = sim.turn[i] === undefined ? REST : sim.turn[i], swing = sim.swing[i] || 0;
    r.slot.style.transform = "translate3d(" + ((sim.x[i] || 0) - w / 2).toFixed(2) + "px,0,0)";
    r.swing.style.transform = "rotate(" + swing.toFixed(3) + "deg)";
    var e = clamp(1 - angle / REST, 0, 1);
    r.turn.style.transform = "perspective(" + PERSPECTIVE + "px) rotateY(" + angle.toFixed(2) + "deg)";
    r.turn.style.opacity = r.side ? clamp((e - 0.44) / 0.12, 0, 1).toFixed(3) : "1";
    if (r.side) {
      r.side.style.opacity = clamp((0.56 - e) / 0.12, 0, 1).toFixed(3);
      r.side.style.transform = "perspective(" + PERSPECTIVE + "px) rotateY(" + (Math.min(1, e * 2) * -84).toFixed(2) + "deg)";
    }
    var lag = clamp(-(sim.vswing[i] || 0) * 0.018, -5, 5);
    r.drape.style.setProperty("--drape", lag.toFixed(3) + "deg");
    r.shade.style.setProperty("--shade", (1 - lambert(angle)).toFixed(3));
    r.shadow.style.transform = "translate3d(" + (w * 0.05).toFixed(1) + "px," + (h * 0.035).toFixed(1) + "px,0) scaleX(" + Math.max(0.12, Math.abs(Math.cos(angle * Math.PI / 180))).toFixed(3) + ")";
    if (r.tag) r.tag.style.transform = "rotate(" + (-12 + (sim.tag[i] || 0)).toFixed(2) + "deg)";
  }

  function step(now) {
    var s = sim, n = count;
    var dt = s.last ? Math.min(0.034, (now - s.last) / 1000) : 1 / 60;
    s.last = now;
    var h = size.h, width = size.width, carousel = size.carousel, busy = false, sub = 2, sdt = dt / sub;
    for (var k = 0; k < sub; k++) {
      for (var i = 0; i < n; i++) {
        var before = s.vx[i] || 0;
        if (i !== s.drag) {
          var restoring = now > s.free, stiff = restoring ? 130 : 0, damp = restoring ? 2 * Math.sqrt(130) * 0.86 : 3.2;
          var ax = -stiff * ((s.x[i] || 0) - (s.tx[i] || 0)) - damp * before;
          s.vx[i] = before + ax * sdt;
          s.x[i] = (s.x[i] || 0) + s.vx[i] * sdt;
        }
        var accel = ((s.vx[i] || 0) - before) / sdt;
        var ta = -150 * ((s.turn[i] || 0) - (s.tturn[i] || 0)) - 2 * Math.sqrt(150) * 0.78 * (s.vturn[i] || 0);
        s.vturn[i] = (s.vturn[i] || 0) + ta * sdt;
        s.turn[i] = (s.turn[i] || 0) + s.vturn[i] * sdt;
        var sa = -24 * (s.swing[i] || 0) - 2.1 * (s.vswing[i] || 0) - clamp(accel, -6000, 6000) * 0.0045;
        s.vswing[i] = (s.vswing[i] || 0) + sa * sdt;
        s.swing[i] = clamp((s.swing[i] || 0) + s.vswing[i] * sdt, -12, 12);
        var tagA = -46 * ((s.tag[i] || 0) - (s.swing[i] || 0) * 0.6) - 3.4 * (s.vtag[i] || 0) - (s.vswing[i] || 0) * 0.9;
        s.vtag[i] = (s.vtag[i] || 0) + tagA * sdt;
        s.tag[i] = clamp((s.tag[i] || 0) + s.vtag[i] * sdt, -30, 30);
      }
      for (var pass = 0; pass < 2; pass++) {
        for (var j = 0; j < n - 1; j++) {
          var a = s.x[j] || 0, b = s.x[j + 1] || 0;
          var minGap = (footprint(h, s.turn[j] === undefined ? REST : s.turn[j], sideWidths[j]) + footprint(h, s.turn[j + 1] === undefined ? REST : s.turn[j + 1], sideWidths[j + 1])) / 2 + h * 0.012;
          var overlap = minGap - (b - a);
          if (overlap <= 0) continue;
          if (j === s.drag) s.x[j + 1] = b + overlap;
          else if (j + 1 === s.drag) s.x[j] = a - overlap;
          else { s.x[j] = a - overlap / 2; s.x[j + 1] = b + overlap / 2; }
          var va = s.vx[j] || 0, vb = s.vx[j + 1] || 0;
          if (va > vb) { var shared = (va + vb) / 2; if (j !== s.drag) s.vx[j] = shared; if (j + 1 !== s.drag) s.vx[j + 1] = shared; }
        }
      }
      if (!carousel && n > 0) {
        var edge = h * 0.06;
        var first = edge + footprint(h, s.turn[0] === undefined ? REST : s.turn[0], sideWidths[0]) / 2;
        var last = width - edge - footprint(h, s.turn[n - 1] === undefined ? REST : s.turn[n - 1], sideWidths[n - 1]) / 2;
        if ((s.x[0] || 0) < first) { s.x[0] = first; s.vx[0] = Math.abs(s.vx[0] || 0) * 0.3; }
        if ((s.x[n - 1] || 0) > last) { s.x[n - 1] = last; s.vx[n - 1] = -Math.abs(s.vx[n - 1] || 0) * 0.3; }
      }
    }
    for (var q = 0; q < n; q++) {
      paint(q);
      if (Math.abs(s.vx[q] || 0) > 0.4 || (now > s.free && Math.abs((s.x[q] || 0) - (s.tx[q] || 0)) > 0.25) ||
          Math.abs((s.turn[q] || 0) - (s.tturn[q] || 0)) > 0.05 || Math.abs(s.vturn[q] || 0) > 0.05 ||
          Math.abs(s.swing[q] || 0) > 0.02 || Math.abs(s.vswing[q] || 0) > 0.05 ||
          Math.abs(s.tag[q] || 0) > 0.05 || Math.abs(s.vtag[q] || 0) > 0.08) busy = true;
    }
    if (s.drag >= 0 || now < s.free) busy = true;
    if (busy) s.raf = requestAnimationFrame(step);
    else {
      s.raf = 0; s.last = 0;
      for (var z = 0; z < n; z++) { if (now > s.free) s.x[z] = s.tx[z] || 0; s.swing[z] = 0; s.vswing[z] = 0; s.tag[z] = 0; s.vtag[z] = 0; paint(z); }
    }
  }

  function kick() {
    if (reduced) {
      for (var i = 0; i < count; i++) { sim.x[i] = sim.tx[i] || 0; sim.turn[i] = sim.tturn[i] === undefined ? REST : sim.tturn[i]; sim.vx[i] = 0; sim.vturn[i] = 0; sim.swing[i] = 0; sim.vswing[i] = 0; paint(i); }
      return;
    }
    if (!sim.raf) { sim.last = 0; sim.raf = requestAnimationFrame(step); }
  }

  function impulse(i, amount) {
    if (reduced || i < 0 || i >= count) return;
    sim.vswing[i] = (sim.vswing[i] || 0) + amount;
    kick();
  }

  // ---------------------------------------------------------------- selection
  function choose(index) {
    var old = active;
    if (old === index) return;
    if (index !== null) { impulse(index - 1, -30); impulse(index + 1, 30); carouselIndex = index; lastShown = index; }
    if (old !== null) { impulse(old - 1, 14); impulse(old + 1, -14); }
    active = index;
    retarget(false);
    renderDots();
    renderCaption();
  }

  // Click on a piece = the original "lift" dialog (Detail). Inside it, "View details" goes to the product page.
  function open(index) {
    stop();
    choose(index);
    if (props.liftDialog === false) { emit("open", items[index].id); return; }
    openDetail(index);
  }

  // ---------------------------------------------------------------- Detail dialog (port of the original <Detail/>)
  var detail = null;
  function openDetail(index) {
    if (detail) return;
    var item = items[index];
    var d = detail = { index: index, side: "front", closing: false,
      a: { value: 0, target: 0, velocity: 0, raf: 0, last: 0, dragging: false, startX: 0, startAngle: 0 } };

    var dlg = d.el = el("div", "dlg", { role: "dialog", "aria-modal": "true", "aria-labelledby": "dlg-title" });
    var backdrop = el("div", "dlg-backdrop", { "aria-hidden": "true" });
    backdrop.addEventListener("click", dismiss);
    var close = d.closeBtn = el("button", "dlg-close", { type: "button" });
    close.innerHTML = '<span></span><svg aria-hidden="true" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3 3l10 10M13 3L3 13"/></svg>';
    close.firstChild.textContent = props.closeLabel || "Close";
    close.addEventListener("click", dismiss);

    var grid = el("div", "dlg-grid");
    var figure = d.figure = el("div", "dlg-figure");
    figure.appendChild(el("div", "dlg-rod", { "aria-hidden": "true" }));
    var drag = el("div", "dlg-drag");
    var spinEl = d.spin = el("div", "dlg-spin");
    ["front", "back"].forEach(function (face) {
      var f = el("div", "dlg-face " + face);
      var src = face === "back" ? (item.backImage || item.image) : item.image;
      var img = el("img", "photo", { src: src, alt: face === "front" ? item.name : "", draggable: "false" });
      f.appendChild(img); spinEl.appendChild(f);
    });
    drag.appendChild(spinEl); figure.appendChild(drag);
    drag.addEventListener("pointerdown", function (e) { var a = d.a; a.dragging = true; a.startX = e.clientX; a.startAngle = a.value; cancelAnimationFrame(a.raf); a.raf = 0; a.last = 0; drag.setPointerCapture(e.pointerId); });
    drag.addEventListener("pointermove", function (e) { var a = d.a; if (!a.dragging) return; a.value = clamp(a.startAngle + (e.clientX - a.startX) * 0.45, a.startAngle - 220, a.startAngle + 220); spinEl.style.transform = "rotateY(" + a.value.toFixed(2) + "deg)"; });
    drag.addEventListener("pointerup", function () { var a = d.a; if (!a.dragging) return; a.dragging = false; var facing = ((a.value % 360) + 360) % 360; turnTo(facing > 90 && facing < 270 ? "back" : "front"); });
    drag.addEventListener("pointercancel", function () { d.a.dragging = false; turnTo(d.side); });

    var info = d.info = el("div", "dlg-info");
    var num = el("p", "dlg-count"); num.textContent = String(index + 1).padStart(2, "0") + " / " + String(count).padStart(2, "0");
    var title = el("h3", "dlg-title", { id: "dlg-title" }); title.textContent = item.name;
    info.appendChild(num); info.appendChild(title);
    if (item.description) { var desc = el("p", "dlg-desc"); desc.textContent = item.description; info.appendChild(desc); }
    if (item.details && item.details.length) {
      var ul = el("ul", "dlg-chips");
      item.details.forEach(function (t) { var li = el("li"); li.textContent = t; ul.appendChild(li); });
      info.appendChild(ul);
    }
    var faces = el("div", "dlg-faces", { role: "group", "aria-label": "Front / Back" });
    d.faceBtns = {};
    ["front", "back"].forEach(function (face) {
      var b = el("button", "dlg-face-btn", { type: "button", "aria-pressed": String(face === "front") });
      b.innerHTML = "<span></span><i aria-hidden='true'></i>";
      b.firstChild.textContent = face === "front" ? (props.frontLabel || "Front") : (props.backLabel || "Back");
      b.addEventListener("click", function () { turnTo(face); });
      d.faceBtns[face] = b; faces.appendChild(b);
    });
    info.appendChild(faces);
    if (props.detailsLabel) {
      var go = el("button", "rail-action dlg-go", { type: "button" });
      go.textContent = props.detailsLabel;
      go.addEventListener("click", function () { emit("open", item.id); });
      info.appendChild(go);
    }

    grid.appendChild(figure); grid.appendChild(info);
    dlg.appendChild(backdrop); dlg.appendChild(close); dlg.appendChild(grid);
    dlg.addEventListener("keydown", onDetailKey);
    document.body.appendChild(dlg);
    reportHeight();

    // lift animation from the piece on the rail
    var from = refs[index].turn.getBoundingClientRect(), to = figure.getBoundingClientRect();
    refs[index].slot.style.visibility = "hidden";
    if (!reduced && from.width > 0 && figure.animate) {
      var scale = from.height / to.height, dx = from.left + from.width / 2 - (to.left + to.width / 2), dy = from.top - to.top;
      var lift = Math.min(90, Math.abs(dy) * 0.25 + 30);
      figure.animate([
        { transform: "translate(" + dx + "px," + dy + "px) scale(" + scale + ")" },
        { transform: "translate(" + dx * 0.4 + "px," + (dy * 0.4 - lift) + "px) scale(" + ((scale + 1) / 2 * 1.03) + ") rotate(" + (dx > 0 ? -2.5 : 2.5) + "deg)", offset: 0.5 },
        { transform: "none" },
      ], { duration: 680, easing: "cubic-bezier(.22,.85,.3,1)" });
    }
    requestAnimationFrame(function () { dlg.classList.add("shown"); });
    close.focus({ preventScroll: true });
  }

  function spinLoop() {
    var d = detail; if (!d) return;
    var a = d.a, node = d.spin;
    if (reduced) { a.value = a.target; node.style.transform = "rotateY(" + a.value + "deg)"; return; }
    if (a.raf) return;
    function loop(now) {
      var dt = a.last ? Math.min(0.034, (now - a.last) / 1000) : 1 / 60;
      a.last = now;
      var accel = -90 * (a.value - a.target) - 2 * Math.sqrt(90) * 0.82 * a.velocity;
      a.velocity += accel * dt; a.value += a.velocity * dt;
      node.style.transform = "rotateY(" + a.value.toFixed(2) + "deg)";
      if (Math.abs(a.value - a.target) < 0.05 && Math.abs(a.velocity) < 0.05) { a.value = a.target; node.style.transform = "rotateY(" + a.value + "deg)"; a.raf = 0; a.last = 0; return; }
      a.raf = requestAnimationFrame(loop);
    }
    a.raf = requestAnimationFrame(loop);
  }

  function turnTo(next) {
    var d = detail; if (!d) return;
    var a = d.a, base = Math.round(a.value / 360) * 360;
    a.target = base + (next === "back" ? 180 : 0);
    if (Math.abs(a.target - a.value) > 180) a.target -= 360 * Math.sign(a.target - a.value);
    d.side = next;
    ["front", "back"].forEach(function (f) { d.faceBtns[f].setAttribute("aria-pressed", String(f === next)); });
    spinLoop();
  }

  function dismiss() {
    var d = detail; if (!d || d.closing) return;
    d.closing = true;
    d.el.classList.remove("shown");
    var slot = refs[d.index].slot, to = refs[d.index].turn;
    function finish() {
      cancelAnimationFrame(d.a.raf);
      d.el.remove(); detail = null;
      slot.style.visibility = "";
      impulse(d.index, (d.index % 2 ? 1 : -1) * 44);
      slot.focus({ preventScroll: true });
      reportHeight();
    }
    slot.style.visibility = "";
    var target = to.getBoundingClientRect();
    slot.style.visibility = "hidden";
    if (reduced || !d.figure.animate || target.width === 0) { finish(); return; }
    var from = d.figure.getBoundingClientRect(), scale = target.height / from.height;
    var dx = target.left + target.width / 2 - (from.left + from.width / 2), dy = target.top - from.top;
    var anim = d.figure.animate([
      { transform: "none" },
      { transform: "translate(" + dx * 0.6 + "px," + (dy * 0.6 - 30) + "px) scale(" + (scale + 1) / 2 + ")", offset: 0.55 },
      { transform: "translate(" + dx + "px," + dy + "px) scale(" + scale + ")" },
    ], { duration: 560, easing: "cubic-bezier(.45,0,.55,1)", fill: "forwards" });
    anim.onfinish = finish;
  }

  function onDetailKey(event) {
    var d = detail; if (!d) return;
    if (event.key === "Escape") { event.preventDefault(); dismiss(); return; }
    if (event.key === "ArrowLeft" || event.key === "ArrowRight") { turnTo(d.side === "front" ? "back" : "front"); return; }
    if (event.key !== "Tab") return;
    var controls = Array.prototype.filter.call(d.el.querySelectorAll("button"), function (n) { return !n.disabled; });
    var first = controls[0], last = controls[controls.length - 1];
    if (!first) return;
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }

  function stop() { playing = false; clearTimeout(timer); }
  function startAutoplay() {
    clearTimeout(timer);
    if (!playing || reduced || !count) return;
    timer = setTimeout(function advance() {
      if (!playing || detail) return;
      choose(active === null ? 0 : (active + 1) % count);
      timer = setTimeout(advance, props.interval || 2600);
    }, active === null ? 1100 : (props.interval || 2600));
  }

  function renderDots() {
    dotsEl.innerHTML = "";
    if (!size.carousel || count < 2) { dotsEl.style.display = "none"; return; }
    dotsEl.style.display = "";
    var current = active === null ? carouselIndex : active;
    items.forEach(function (item, i) {
      var d = el("button", "dot", { type: "button", "aria-label": "Show " + item.name, "aria-current": String(current === i) });
      d.addEventListener("click", function () { stop(); choose(i); });
      dotsEl.appendChild(d);
    });
  }

  // Same as the original: name (or the caption) + description, then the action button.
  function renderCaption() {
    var item = active === null ? null : items[active];
    capEl.innerHTML = "";
    var text = el("div", "caption-text", { id: "rail-caption", "aria-live": "polite" });
    var name = el("p", "caption-name");
    name.textContent = item ? item.name : (props.caption || "");
    text.appendChild(name);
    if (item && item.description) { var d = el("p", "caption-desc"); d.textContent = item.description; text.appendChild(d); }
    if (item && props.hint) { var h = el("p", "caption-hint"); h.textContent = props.hint; text.appendChild(h); }
    capEl.appendChild(text);
    if (props.actionLabel) {
      var btn = el("button", "rail-action", { type: "button" });
      btn.textContent = props.actionLabel;
      btn.addEventListener("click", function () {
        stop();
        var index = active === null ? lastShown : active;   // the piece the visitor last looked at
        if (items[index]) emit("action", items[index].id);
      });
      capEl.appendChild(btn);
    }
  }

  // ---------------------------------------------------------------- pointer + keyboard
  function nearest(clientX, clientY) {
    var box = stageEl.getBoundingClientRect(), x = clientX - box.left, y = clientY - box.top, h = size.h;
    if (y < 0 || y > h + 46) return null;
    var best = null, dist = Infinity;
    for (var i = 0; i < count; i++) {
      var half = footprint(h, sim.turn[i] === undefined ? REST : sim.turn[i], sideWidths[i]) / 2 + 4;
      var d = Math.abs(x - (sim.x[i] || 0));
      if (d < half && d < dist) { best = i; dist = d; }
    }
    return best;
  }

  function onPointerMove(event) {
    var p = pointer, s = sim;
    if (p.id === event.pointerId) {
      var dx = event.clientX - p.x, now = performance.now();
      if (!p.moved && Math.abs(dx) > 6 && Math.abs(dx) > Math.abs(event.clientY - p.y)) {
        p.moved = true; stop();
        try { stageEl.setPointerCapture(event.pointerId); } catch (e) { /* ignore */ }
        if (!size.carousel && p.index >= 0) {
          s.drag = p.index;
          s.grab = (event.clientX - stageEl.getBoundingClientRect().left) - (s.x[p.index] || 0);
        }
      }
      if (p.moved) {
        var v = (event.clientX - p.lastX) / Math.max(1, now - p.lastT);
        p.v = p.v * 0.6 + v * 0.4; p.lastX = event.clientX; p.lastT = now;
        if (s.drag >= 0) {
          s.vx[s.drag] = p.v * 1000;
          s.x[s.drag] = event.clientX - stageEl.getBoundingClientRect().left - s.grab;
          s.free = now + 900;
          kick();
        } else if (size.carousel) {
          p.swipe = dx;
          var xs = targets(size.h, size.width, true, active === null ? carouselIndex : active);
          for (var i = 0; i < count; i++) s.tx[i] = xs[i] + dx;
          kick();
        }
      }
      return;
    }
    if (event.pointerType !== "mouse" || size.carousel || detail) return;
    var hit = nearest(event.clientX, event.clientY);
    if (active !== null && hit !== active) {
      var box = stageEl.getBoundingClientRect();
      var keep = Math.abs(event.clientX - box.left - (s.x[active] || 0)) < footprint(size.h, 0) / 2 + 14;
      if (keep && (hit === null || Math.abs(event.clientY - box.top) < size.h + 40)) return;
    }
    if (hit !== null) { stop(); choose(hit); }
  }

  function onPointerDown(event) {
    if (event.button !== 0) return;
    var hit = nearest(event.clientX, event.clientY), now = performance.now();
    pendingOpen = -1;
    pointer = { id: event.pointerId, index: hit === null ? -1 : hit, x: event.clientX, y: event.clientY, moved: false, kind: event.pointerType, swipe: 0, lastX: event.clientX, lastT: now, v: 0 };
  }

  function finishPointer(event, cancelled) {
    var p = pointer;
    if (p.id !== event.pointerId) return;
    try { if (stageEl.hasPointerCapture(event.pointerId)) stageEl.releasePointerCapture(event.pointerId); } catch (e) { /* ignore */ }
    pointer = Object.assign({}, p, { id: -1 });
    if (sim.drag >= 0) { sim.drag = -1; sim.free = performance.now() + 700; kick(); return; }
    if (p.moved && size.carousel) {
      var dx = event.clientX - p.x, current = active === null ? carouselIndex : active;
      var stepBy = Math.abs(dx) > 40 || Math.abs(p.v) > 0.45 ? (dx < 0 ? 1 : -1) : 0;
      pointer.swipe = 0;
      choose(clamp(current + stepBy, 0, count - 1));
      retarget(false);
      for (var i = 0; i < count; i++) impulse(i, clamp(-p.v * 22, -30, 30));
      return;
    }
    if (cancelled || p.moved || p.index < 0) return;
    stop();
    if (p.kind !== "mouse" && active !== p.index) choose(p.index);
    else pendingOpen = p.index;
  }

  function onKeyDown(event) {
    var keys = ["ArrowRight", "ArrowLeft", "Home", "End"];
    if (keys.indexOf(event.key) < 0) return;
    event.preventDefault(); stop();
    var from = active === null ? focusIndex : active;
    var next = event.key === "Home" ? 0 : event.key === "End" ? count - 1 : clamp(from + (event.key === "ArrowRight" ? 1 : -1), 0, count - 1);
    focusIndex = next; choose(next);
    refs[next].slot.focus({ preventScroll: true });
  }

  // ---------------------------------------------------------------- render from Streamlit
  var lastKey = "";
  function render(args) {
    var key = JSON.stringify([args.items, args.eyebrow, args.heading, args.caption, args.hint, args.actionLabel, args.fillViewport]);
    props = args;
    if (key !== lastKey) {
      lastKey = key;
      items = (args.items || []).filter(function (it) { return it && it.image; });
      count = items.length;
      sideWidths = items.map(function (it) { return it.sideImage ? 0.3 : 0.4; });
      build();
    }
    root.classList.toggle("fill", !!args.fillViewport);
    var wantPlay = !!args.autoplay;
    if (wantPlay && !playing && !timer) { playing = true; startAutoplay(); }
    if (!wantPlay) stop();
    reportHeight();
  }

  window.addEventListener("message", function (event) {
    var data = event.data;
    if (data && data.type === "streamlit:render") render(data.args || {});
  });
  window.addEventListener("resize", function () { if (stageEl) measure(); });
  if ("ResizeObserver" in window) new ResizeObserver(function () { if (stageEl) measure(); reportHeight(); }).observe(document.body);

  post("streamlit:componentReady", { apiVersion: 1 });
  window.__railDebug = { state: function () { return { active: active, size: size, count: count, x: sim.x.slice() }; }, render: render };
})();
