"""
Interactive clothing rail (Streamlit custom component, no build step).

A plain-JavaScript port of the <ClothingRailHero/> React component, served
from ./static. Garments hang side-on on a metal rail, turn to the front on
hover, can be slid along the rail, and open the product page on click.

The original React/TypeScript source is kept in ./frontend for reference only;
it is not used at runtime (the site does not depend on React or Node).

Event returned to Python: {"type": "open" | "action", "id": <product id>, "nonce": int}
"open" = "View details" in the lift dialog (or a click, with lift_dialog=False);
"action" = the button under the caption was pressed.
"nonce" is unique per click, so compare it with the last one you handled.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

import streamlit.components.v1 as components

_STATIC = Path(__file__).resolve().parent / "static"
_component = components.declare_component("fitted_clothing_rail", path=str(_STATIC))

_FIELDS = ("id", "name", "description", "tag", "image", "backImage", "sideImage", "details")


def clothing_rail(
    items: list[dict],
    *,
    eyebrow: str = "",
    heading: str = "",
    caption: str = "",
    hint: str = "",
    action_label: str = "",
    details_label: str = "View details",
    lift_dialog: bool = True,
    fill_viewport: bool = False,
    autoplay: bool = True,
    interval: int = 2600,
    key: Optional[str] = None,
) -> Optional[dict[str, Any]]:
    """Render the rail; returns the latest click event or None."""
    payload = [{k: item.get(k) for k in _FIELDS if item.get(k) is not None} for item in items]
    return _component(
        items=payload,
        eyebrow=eyebrow,
        heading=heading,
        caption=caption,
        hint=hint,
        actionLabel=action_label,
        detailsLabel=details_label,
        liftDialog=lift_dialog,
        fillViewport=fill_viewport,
        autoplay=autoplay,
        interval=interval,
        key=key,
        default=None,
    )
