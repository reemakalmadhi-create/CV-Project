"""
Visual layer helpers: theme CSS, the GSAP motion script, Lottie players and
browser-cookie writes.

GSAP and lottie-web are loaded from cdnjs in the visitor's browser (nothing is
installed on the server). Everything degrades gracefully: if a CDN is
unreachable, pages render normally without motion and Lottie spots show a
static icon instead.
"""

from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path
from typing import Optional

import streamlit as st
import streamlit.components.v1 as components

ASSETS = Path(__file__).resolve().parent.parent / "assets"
GSAP_URL = "https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"
LOTTIE_URL = "https://cdnjs.cloudflare.com/ajax/libs/lottie-web/5.12.2/lottie_light.min.js"

# Static fallback icons (shown until / unless Lottie loads)
_FALLBACK = {
    "processing": "&#9711;", "success": "&#10003;", "upload": "&#8593;",
    "empty_favorites": "&#9825;", "empty_cart": "&#9634;", "error": "!",
}


def html_frame(html: str, height: int) -> None:
    """Render HTML in an iframe: st.iframe on new Streamlit, components.html on older."""
    if hasattr(st, "iframe"):
        st.iframe(html, height=max(1, int(height)))
    else:
        components.html(html, height=height)


@lru_cache(maxsize=None)
def _read(path: str) -> str:
    return (ASSETS / path).read_text(encoding="utf-8")


def _js_string(text: str) -> str:
    """Embed arbitrary text safely inside an inline <script>."""
    return json.dumps(text).replace("</", "<\\/")


# ------------------------------------------------------------------ theme + motion
def inject_theme() -> None:
    st.html(f"<style>{_read('css/fitted.css')}</style>")


def inject_fx() -> None:
    """Load GSAP + assets/js/fx.js into the Streamlit page (once per tab)."""
    source = _read("js/fx.js")
    version = hashlib.sha1(source.encode()).hexdigest()[:10]
    script = f"""
<script>
(function () {{
  try {{
    var P = window.parent, d = P.document;
    var VERSION = {json.dumps(version)}, SRC = {_js_string(source)};
    function run() {{
      if (P.__fittedFxVersion !== VERSION) {{
        P.__fittedFx = null; P.__fittedFxVersion = VERSION;
        var s = d.createElement("script"); s.id = "ft-fx"; s.textContent = SRC; d.head.appendChild(s);
      }} else if (P.__fittedFx) {{ P.__fittedFx.scan(); }}
    }}
    if (P.gsap) {{ run(); return; }}
    var tag = d.getElementById("ft-gsap");
    if (!tag) {{
      tag = d.createElement("script"); tag.id = "ft-gsap"; tag.src = {json.dumps(GSAP_URL)};
      tag.crossOrigin = "anonymous"; d.head.appendChild(tag);
    }}
    tag.addEventListener("load", run);
  }} catch (err) {{ console.warn("FITTED fx unavailable", err); }}
}})();
</script>"""
    with st.container(key="ft-fx"):
        html_frame(script, height=1)


# ------------------------------------------------------------------ lottie
def lottie(name: str, height: int = 160, loop: bool = True, caption: Optional[str] = None) -> None:
    """Render assets/lottie/<name>.json (minimal monochrome animations)."""
    data = _read(f"lottie/{name}.json")
    fallback = _FALLBACK.get(name, "")
    caption_html = (
        f'<p style="margin:.6rem 0 0;font:500 13px Manrope,Inter,system-ui,sans-serif;color:#777;text-align:center">{caption}</p>'
        if caption else ""
    )
    size = height - (34 if caption else 0)
    html = f"""
<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:{height}px">
  <div id="anim" style="width:{size}px;height:{size}px;position:relative">
    <div id="fb" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
         font:300 {int(size * .38)}px/1 system-ui,sans-serif;color:#111">{fallback}</div>
  </div>{caption_html}
</div>
<script src="{LOTTIE_URL}"></script>
<script>
(function () {{
  if (!window.lottie) return;
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  document.getElementById("fb").remove();
  var a = lottie.loadAnimation({{ container: document.getElementById("anim"), renderer: "svg",
    loop: {str(bool(loop)).lower()} && !reduce, autoplay: !reduce, animationData: {data.replace("</", "<\\/")} }});
  if (reduce) a.goToAndStop(a.totalFrames - 1, true);
}})();
</script>"""
    html_frame(html, height)


# ------------------------------------------------------------------ cookies
def run_cookie_ops(ops: list[tuple]) -> None:
    """Write/clear cookies on the Streamlit page (for remember-me)."""
    if not ops:
        return
    lines = []
    for op, name, value, max_age in ops:
        age = int(max_age) if op == "set" else 0
        lines.append(
            f"d.cookie = {json.dumps(name)} + '=' + encodeURIComponent({json.dumps(value)}) + "
            f"'; Path=/; Max-Age={age}; SameSite=Lax' + secure;"
        )
    script = (
        "<script>try{var P=window.parent,d=P.document,"
        "secure=P.location.protocol==='https:'?'; Secure':'';"
        + "".join(lines)
        + "}catch(e){console.warn('cookie write failed',e)}</script>"
    )
    with st.container(key="ft-cookies"):
        html_frame(script, height=1)
