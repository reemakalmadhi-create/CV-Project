"""Person-photo uploader: drag & drop, preview, validation, remove.

The accepted photo is kept in session state (bytes) so it survives page
changes, e.g. trying several garments with the same photo.
"""

from __future__ import annotations

import html
from typing import Optional

import streamlit as st
from PIL import Image

from components.animations import lottie
from utils.images import ImageReport, validate_person_photo

STATE = "person_photo"        # {"bytes", "name", "checks": [(label, ok, blocking)]}
VERSION = "person_photo_ver"  # bump to reset the file_uploader widget


def _checklist(checks: list[tuple]) -> str:
    rows = []
    for label, ok, blocking in checks:
        cls, mark = ("", "✓") if ok else (("bad", "✕") if blocking else ("warn", "!"))
        rows.append(f'<li class="{cls}"><span>{mark}</span><span>{html.escape(label)}</span></li>')
    return f'<ul class="ft-checklist">{"".join(rows)}</ul>'


def clear() -> None:
    st.session_state[STATE] = None
    st.session_state[VERSION] = st.session_state.get(VERSION, 0) + 1


def current_image() -> Optional[Image.Image]:
    stored = st.session_state.get(STATE)
    if not stored:
        return None
    report = validate_person_photo(stored["bytes"])
    return report.image if report.accepted else None


def render() -> Optional[Image.Image]:
    """Draw the uploader or the preview; returns the accepted image or None."""
    st.session_state.setdefault(STATE, None)
    st.session_state.setdefault(VERSION, 0)
    stored = st.session_state[STATE]

    if stored is None:
        st.markdown(
            "<p class='ft-small'>Use a well-lit, front-facing photo with your full body (or at least your upper body) "
            "visible, arms slightly away from the body, on a plain background. JPG, PNG or WEBP, up to 10 MB.</p>",
            unsafe_allow_html=True,
        )
        file = st.file_uploader(
            "Drag and drop your photo here, or browse files",
            type=["jpg", "jpeg", "png", "webp"],
            key=f"person-upload-{st.session_state[VERSION]}",
            label_visibility="collapsed",
        )
        if file is None:
            lottie("upload", height=92)
            return None
        data = file.getvalue()
        report: ImageReport = validate_person_photo(data)
        checks = [(c.label, c.ok, c.blocking) for c in report.checks]
        if not report.accepted:
            st.markdown(_checklist(checks), unsafe_allow_html=True)
            st.error("This photo can't be used. Please fix the points marked ✕ and upload again.")
            return None
        st.session_state[STATE] = {"bytes": data, "name": file.name, "checks": checks, "fresh": True}
        st.rerun()

    report = validate_person_photo(stored["bytes"])
    if stored.pop("fresh", False):
        lottie("success", height=90, loop=False)
    st.markdown(
        f"<div class='ft-small' style='margin-bottom:.4rem'>{html.escape(stored['name'])}</div>",
        unsafe_allow_html=True,
    )
    st.image(report.image, width="stretch")
    st.markdown(_checklist(stored["checks"]), unsafe_allow_html=True)
    if report.warnings:
        st.caption("Warnings won't block you, but fixing them gives the model a better input.")
    if st.button("Remove photo", key="photo-remove", icon=":material/delete:", width="stretch"):
        clear()
        st.rerun()
    return report.image if report.accepted else None
