"""Opening splash — a fitting-room curtain.

A closed curtain (rod + rings + fabric folds) fills the screen, FITTED writes in,
a thin line fills underneath, then the curtain draws open to both sides and the
site appears behind it.

Built ONLY from <div>/<span> + CSS keyframes, because Streamlit's HTML sanitiser
removes <svg> and <script>. Needs no CDN, always ends by itself (~3.3 s), never
blocks clicks afterwards, respects "reduce motion". Shown once per visit.
"""

from __future__ import annotations

import streamlit as st

OPEN_AT = 2.25   # s — curtain starts opening
DURATION = 3.3   # s — splash fully gone

CSS = f"""
<style>
.ft-splash {{ position: fixed; inset: 0; z-index: 1000000; overflow: hidden; pointer-events: auto;
  animation: ftSpGone .01s linear {DURATION:.2f}s forwards; }}

/* ---- curtain panels: soft vertical folds + shading toward the middle ---- */
.ft-splash .sp-panel {{ position: absolute; top: 0; bottom: 0; width: 50.5%;
  background:
    linear-gradient(to bottom, rgba(0,0,0,.06), transparent 18%, transparent 80%, rgba(0,0,0,.05)),
    repeating-linear-gradient(90deg, #ECECEC 0px, #F7F7F7 14px, #FDFDFD 22px, #F1F1F1 34px, #E4E4E4 46px);
  box-shadow: inset 0 22px 30px -22px rgba(0,0,0,.18); will-change: transform; }}
.ft-splash .sp-left  {{ left: 0;  transform-origin: left center;
  animation: ftSpOpenL 1s cubic-bezier(.76,0,.24,1) {OPEN_AT:.2f}s forwards; }}
.ft-splash .sp-right {{ right: 0; transform-origin: right center;
  animation: ftSpOpenR 1s cubic-bezier(.76,0,.24,1) {OPEN_AT:.2f}s forwards; }}
/* inner edges where the two halves meet */
.ft-splash .sp-left::after, .ft-splash .sp-right::after {{ content: ""; position: absolute; top: 0; bottom: 0; width: 26px; }}
.ft-splash .sp-left::after  {{ right: 0; background: linear-gradient(to left, rgba(0,0,0,.09), transparent); }}
.ft-splash .sp-right::after {{ left: 0;  background: linear-gradient(to right, rgba(0,0,0,.09), transparent); }}
/* rings along the top of each panel */
.ft-splash .sp-rings {{ position: absolute; left: 0; right: 0; top: 10px; height: 16px;
  background: radial-gradient(circle at 12px 8px, transparent 4.2px, #8a8a8a 4.8px, #6d6d6d 6px, transparent 6.6px) 0 0 / 46px 16px repeat-x; }}

/* ---- rod across the top ---- */
.ft-splash .sp-rod {{ position: absolute; left: 3vw; right: 3vw; top: 14px; height: 6px; border-radius: 999px; z-index: 3;
  background: linear-gradient(to bottom, #d4d4d4, #fff 22%, #b2b2b2 45%, #747474 70%, #4a4a4a);
  box-shadow: 0 4px 8px -4px rgba(0,0,0,.35); transform-origin: center;
  animation: ftSpRod .7s cubic-bezier(.2,.8,.2,1) both, ftSpFadeOut .5s ease {OPEN_AT + 0.45:.2f}s forwards; }}
.ft-splash .sp-rod::before, .ft-splash .sp-rod::after {{ content: ""; position: absolute; top: -4px; width: 14px; height: 14px;
  border-radius: 50%; background: radial-gradient(circle at 35% 35%, #eee, #777 70%); }}
.ft-splash .sp-rod::before {{ left: -7px; }}  .ft-splash .sp-rod::after {{ right: -7px; }}

/* ---- brand in the middle ---- */
.ft-splash .sp-brand {{ position: absolute; inset: 0; z-index: 4; display: flex; flex-direction: column;
  align-items: center; justify-content: center; text-align: center;
  animation: ftSpBrandOut .5s cubic-bezier(.4,0,.2,1) {OPEN_AT - 0.15:.2f}s forwards; }}
.ft-splash .sp-eyebrow {{ font: 600 10.5px/1 Manrope, Inter, system-ui, sans-serif; letter-spacing: .34em; text-transform: uppercase;
  color: #777; opacity: 0; animation: ftSpUp .6s ease .25s both; }}
.ft-splash .sp-logo {{ margin-top: 1.1rem; display: flex; padding-left: .42em;
  font: 700 clamp(2.4rem, 6vw, 4rem)/1 Manrope, Inter, system-ui, sans-serif; letter-spacing: .42em; color: #111; }}
.ft-splash .sp-logo span {{ display: inline-block; opacity: 0; animation: ftSpLetter .6s cubic-bezier(.2,.8,.2,1) both; }}
.ft-splash .sp-line {{ margin-top: 1.5rem; width: min(260px, 60vw); height: 1px; background: #E0E0E0; position: relative; overflow: hidden; }}
.ft-splash .sp-line span {{ position: absolute; inset: 0; background: #111; transform-origin: left; transform: scaleX(0);
  animation: ftSpFill 1.5s cubic-bezier(.65,0,.35,1) .55s forwards; }}
.ft-splash .sp-tag {{ margin-top: 1.1rem; font: 500 12.5px/1 Manrope, Inter, system-ui, sans-serif; letter-spacing: .06em;
  color: #777; opacity: 0; animation: ftSpUp .6s ease 1.25s both; }}

@keyframes ftSpRod      {{ from {{ transform: scaleX(0); }} to {{ transform: scaleX(1); }} }}
@keyframes ftSpUp       {{ from {{ opacity: 0; transform: translateY(8px); }} to {{ opacity: 1; transform: none; }} }}
@keyframes ftSpLetter   {{ from {{ opacity: 0; transform: translateY(16px); filter: blur(6px); }}
                           to   {{ opacity: 1; transform: none; filter: none; }} }}
@keyframes ftSpFill     {{ to {{ transform: scaleX(1); }} }}
@keyframes ftSpBrandOut {{ to {{ opacity: 0; transform: translateY(-10px) scale(.98); }} }}
@keyframes ftSpFadeOut  {{ to {{ opacity: 0; }} }}
/* the halves slide out and bunch up (scaleX) like gathered fabric */
@keyframes ftSpOpenL {{ 0% {{ transform: translateX(0) scaleX(1); }} 100% {{ transform: translateX(-92%) scaleX(.55); }} }}
@keyframes ftSpOpenR {{ 0% {{ transform: translateX(0) scaleX(1); }} 100% {{ transform: translateX(92%) scaleX(.55); }} }}
@keyframes ftSpGone  {{ to {{ visibility: hidden; pointer-events: none; opacity: 0; }} }}

@media (prefers-reduced-motion: reduce) {{
  .ft-splash {{ animation: ftSpGone .01s linear 1.2s forwards; }}
  .ft-splash * {{ animation: none !important; opacity: 1 !important; transform: none !important; filter: none !important; }}
}}
</style>
"""


def html() -> str:
    letters = "".join(f'<span style="animation-delay:{0.35 + i * 0.08:.2f}s">{c}</span>' for i, c in enumerate("FITTED"))
    return (
        CSS
        + '<div class="ft-splash" role="presentation" aria-hidden="true">'
        + '<div class="sp-panel sp-left"><div class="sp-rings"></div></div>'
        + '<div class="sp-panel sp-right"><div class="sp-rings"></div></div>'
        + '<div class="sp-rod"></div>'
        + '<div class="sp-brand">'
        + '<div class="sp-eyebrow">AI virtual try-on</div>'
        + f'<div class="sp-logo">{letters}</div>'
        + '<div class="sp-line"><span></span></div>'
        + '<div class="sp-tag">Your style, your fit, your way.</div>'
        + "</div></div>"
    )


def render_once() -> None:
    """Show the splash on the first script run of a browser session (when the site is opened)."""
    if st.session_state.get("splash_done"):
        return
    st.session_state.splash_done = True
    st.html(html())
