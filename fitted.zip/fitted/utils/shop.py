"""
Favorites, cart, orders, saved sizes and try-on history — persisted per user.

Pure Python (no Streamlit) so it can be unit-tested. `utils.session` wraps
these for the pages.
"""

from __future__ import annotations

import secrets
from datetime import datetime, timezone
from typing import Optional

from . import storage
from .catalog import SIZES, get_product, shipping_for

MAX_QTY = 10


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ------------------------------------------------------------ favorites
def toggle_favorite(email: str, product_id: str) -> bool:
    """Add or remove; returns True if the product is now a favorite."""
    state = {}

    def apply(rec: dict) -> None:
        favs = rec.setdefault("favorites", [])
        if product_id in favs:
            favs.remove(product_id)
            state["fav"] = False
        else:
            favs.insert(0, product_id)
            state["fav"] = True

    storage.update_user(email, apply)
    return state["fav"]


def remove_favorite(email: str, product_id: str) -> None:
    storage.update_user(
        email, lambda rec: rec.setdefault("favorites", []).remove(product_id)
        if product_id in rec.get("favorites", []) else None
    )


# ------------------------------------------------------------ cart
def add_to_cart(email: str, product_id: str, size: Optional[str], qty: int = 1, color: Optional[str] = None) -> dict:
    product = get_product(product_id)
    if product is None:
        raise ValueError("This product is no longer available.")
    if size not in SIZES:
        raise ValueError("Please select a size.")
    qty = max(1, min(MAX_QTY, int(qty)))
    color = color or (product.get("colors") or [{"name": ""}])[0]["name"]

    def apply(rec: dict) -> None:
        cart = rec.setdefault("cart", [])
        for line in cart:
            if line["product_id"] == product_id and line["size"] == size and line.get("color") == color:
                line["qty"] = min(MAX_QTY, line["qty"] + qty)
                return
        cart.append({"product_id": product_id, "size": size, "color": color, "qty": qty})

    return storage.update_user(email, apply)


def set_quantity(email: str, index: int, qty: int) -> None:
    def apply(rec: dict) -> None:
        cart = rec.setdefault("cart", [])
        if 0 <= index < len(cart):
            if qty <= 0:
                cart.pop(index)
            else:
                cart[index]["qty"] = min(MAX_QTY, int(qty))

    storage.update_user(email, apply)


def remove_line(email: str, index: int) -> None:
    set_quantity(email, index, 0)


def priced_lines(cart: list[dict]) -> list[dict]:
    """Cart lines joined with product data; unknown products are dropped."""
    lines = []
    for i, line in enumerate(cart):
        product = get_product(line["product_id"])
        if product:
            lines.append({**line, "index": i, "product": product,
                          "line_total": product["price_sar"] * line["qty"]})
    return lines


def totals(cart: list[dict]) -> dict:
    subtotal = sum(l["line_total"] for l in priced_lines(cart))
    shipping = shipping_for(subtotal)
    return {"subtotal": subtotal, "shipping": shipping, "total": subtotal + shipping,
            "count": sum(l["qty"] for l in cart)}


def place_order(email: str) -> dict:
    """Prototype checkout: records the order, empties the cart. No payment."""
    order: dict = {}

    def apply(rec: dict) -> None:
        cart = rec.get("cart", [])
        lines = priced_lines(cart)
        if not lines:
            raise ValueError("Your cart is empty.")
        t = totals(cart)
        order.update({
            "id": "FT-" + secrets.token_hex(3).upper(),
            "created_at": _now(),
            "items": [{"product_id": l["product_id"], "name": l["product"]["name"], "size": l["size"],
                       "color": l.get("color"), "qty": l["qty"], "price_sar": l["product"]["price_sar"]}
                      for l in lines],
            "subtotal": t["subtotal"], "shipping": t["shipping"], "total": t["total"],
            "status": "Placed (prototype — no payment taken)",
        })
        rec.setdefault("orders", []).insert(0, order)
        rec["cart"] = []

    storage.update_user(email, apply)
    return order


# ------------------------------------------------------------ profile
def save_sizes(email: str, sizes: dict) -> None:
    clean = {k: (v if v in SIZES else None) for k, v in sizes.items()}
    storage.update_user(email, lambda rec: rec.setdefault("sizes", {}).update(clean))


def add_tryon_result(email: str, product_id: str, image_filename: str) -> None:
    """Only called with a REAL model output (never with placeholders)."""
    entry = {"id": secrets.token_hex(4), "created_at": _now(),
             "product_id": product_id, "image": image_filename}
    storage.update_user(email, lambda rec: rec.setdefault("tryon_history", []).insert(0, entry))
