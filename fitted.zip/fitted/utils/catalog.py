"""Product catalog (data/products/catalog.json) and price formatting."""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Optional

ROOT = Path(__file__).resolve().parent.parent
CATALOG_FILE = ROOT / "data" / "products" / "catalog.json"

SIZES = ["XS", "S", "M", "L", "XL", "XXL"]
FREE_SHIPPING_FROM = 500   # SAR
SHIPPING_FEE = 25          # SAR, estimate inside Saudi Arabia

SIZE_GUIDE = [
    # size, chest (cm), length (cm), sleeve (cm)
    ("XS", "86–91", "66", "19"),
    ("S", "91–97", "69", "20"),
    ("M", "97–104", "72", "21"),
    ("L", "104–112", "75", "22"),
    ("XL", "112–122", "77", "23"),
    ("XXL", "122–132", "79", "24"),
]


@lru_cache(maxsize=1)
def load_catalog() -> tuple[dict, ...]:
    return tuple(json.loads(CATALOG_FILE.read_text(encoding="utf-8")))


def all_products() -> list[dict]:
    return list(load_catalog())


def get_product(product_id: Optional[str]) -> Optional[dict]:
    return next((p for p in load_catalog() if p["id"] == product_id), None)


def categories() -> list[str]:
    seen: list[str] = []
    for p in load_catalog():
        if p["category"] not in seen:
            seen.append(p["category"])
    return seen


def colour_names() -> list[str]:
    return sorted({c["name"] for p in load_catalog() for c in p.get("colors", [])})


def format_sar(amount: float) -> str:
    return f"SAR {amount:,.0f}" if float(amount).is_integer() else f"SAR {amount:,.2f}"


def shipping_for(subtotal: float) -> float:
    if subtotal <= 0:
        return 0
    return 0 if subtotal >= FREE_SHIPPING_FROM else SHIPPING_FEE
