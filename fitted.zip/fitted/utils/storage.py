"""
Small JSON-file user store.

Each user is one record keyed by lower-cased email:

    {
      "name": str, "email": str,
      "password": {"salt": hex, "hash": hex, "iterations": int},
      "created_at": iso, "avatar": filename | None,
      "favorites": [product_id, ...],
      "cart": [{"product_id", "size", "color", "qty"}, ...],
      "orders": [{"id", "created_at", "items", "subtotal", "shipping", "total", "status"}],
      "sizes": {"upper_body": "M", "lower_body": None, "dresses": None},
      "tryon_history": [{"id", "created_at", "product_id", "image"}],
      "remember_tokens": {sha256(token): expiry_epoch}
    }

Writes are atomic (temp file + rename) and serialised with a lock, which is
enough for a single Streamlit process. For production, swap this module for a
real database — the rest of the app only uses the functions below.

Location: FITTED_DATA_DIR env var, default <project>/data/runtime.
Note: Streamlit Community Cloud's disk is NOT persistent across restarts.
"""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
import threading
from pathlib import Path
from typing import Any, Callable, Optional

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("FITTED_DATA_DIR", PROJECT_ROOT / "data" / "runtime"))
USERS_FILE = DATA_DIR / "users.json"
UPLOADS_DIR = DATA_DIR / "uploads"

_lock = threading.RLock()


def _ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    UPLOADS_DIR.mkdir(parents=True, exist_ok=True)


def _read_all() -> dict[str, dict]:
    if not USERS_FILE.is_file():
        return {}
    try:
        return json.loads(USERS_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        # A corrupt file must not take the site down; keep a copy for inspection.
        backup = USERS_FILE.with_suffix(".corrupt.json")
        try:
            USERS_FILE.replace(backup)
        except OSError:
            pass
        return {}


def _write_all(users: dict[str, dict]) -> None:
    _ensure_dirs()
    fd, tmp = tempfile.mkstemp(dir=DATA_DIR, prefix=".users-", suffix=".json")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(users, fh, ensure_ascii=False, indent=1)
        os.replace(tmp, USERS_FILE)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def key_for(email: str) -> str:
    return (email or "").strip().lower()


def get_user(email: str) -> Optional[dict]:
    with _lock:
        user = _read_all().get(key_for(email))
        return json.loads(json.dumps(user)) if user else None  # defensive copy


def user_exists(email: str) -> bool:
    return get_user(email) is not None


def create_user(record: dict) -> None:
    with _lock:
        users = _read_all()
        k = key_for(record["email"])
        if k in users:
            raise ValueError("An account with this email already exists.")
        users[k] = record
        _write_all(users)


def update_user(email: str, mutate: Callable[[dict], Any]) -> dict:
    """Load, mutate in place, save. Returns the updated record."""
    with _lock:
        users = _read_all()
        k = key_for(email)
        if k not in users:
            raise KeyError(email)
        mutate(users[k])
        _write_all(users)
        return json.loads(json.dumps(users[k]))


def rename_user(old_email: str, new_email: str) -> None:
    with _lock:
        users = _read_all()
        old, new = key_for(old_email), key_for(new_email)
        if old == new:
            return
        if new in users:
            raise ValueError("Another account already uses this email.")
        record = users.pop(old)
        record["email"] = new_email.strip()
        users[new] = record
        _write_all(users)
        old_dir, new_dir = _upload_path(old), _upload_path(new)
        if old_dir.is_dir() and not new_dir.exists():
            old_dir.rename(new_dir)


def delete_user(email: str) -> None:
    with _lock:
        users = _read_all()
        users.pop(key_for(email), None)
        _write_all(users)


def find_user_by(predicate: Callable[[dict], bool]) -> Optional[dict]:
    with _lock:
        for record in _read_all().values():
            if predicate(record):
                return json.loads(json.dumps(record))
    return None


def _upload_path(email: str) -> Path:
    return UPLOADS_DIR / hashlib.sha256(key_for(email).encode()).hexdigest()[:16]


def user_upload_dir(email: str) -> Path:
    folder = _upload_path(email)
    folder.mkdir(parents=True, exist_ok=True)
    return folder
