"""
Streamlit session state: who is logged in, navigation helpers and thin
wrappers around utils.shop that keep the session copy of the user fresh.
"""

from __future__ import annotations

from typing import Optional

import streamlit as st

from . import authentication as auth
from . import shop, storage

REMEMBER_COOKIE = "fitted_remember"

PAGES = {
    "login": "pages/login.py",
    "signup": "pages/signup.py",
    "home": "pages/home.py",
    "closet": "pages/closet.py",
    "product": "pages/product_details.py",
    "tryon": "pages/try_on.py",
    "favorites": "pages/favorites.py",
    "cart": "pages/cart.py",
    "profile": "pages/profile.py",
}


def init_state() -> None:
    ss = st.session_state
    ss.setdefault("user", None)               # public user record (no secrets)
    ss.setdefault("cookie_checked", False)
    ss.setdefault("cookie_ops", [])           # queued browser cookie writes
    ss.setdefault("product_id", None)         # product shown on details page
    ss.setdefault("tryon_product_id", None)   # garment sent to the try-on page
    ss.setdefault("flash", None)              # one-shot toast message


# ------------------------------------------------------------ identity
def current_user() -> Optional[dict]:
    return st.session_state.get("user")


def email() -> str:
    user = current_user()
    return user["email"] if user else ""


def refresh_user() -> Optional[dict]:
    user = current_user()
    if not user:
        return None
    record = storage.get_user(user["email"])
    st.session_state.user = auth.public_user(record) if record else None
    return st.session_state.user


def login(user: dict, remember: bool) -> None:
    st.session_state.user = user
    st.session_state.cookie_checked = True
    if remember:
        token = auth.issue_remember_token(user["email"])
        st.session_state.cookie_ops.append(("set", REMEMBER_COOKIE, token, auth.REMEMBER_DAYS * 86400))


def logout() -> None:
    user = current_user()
    token = _cookie_token()
    if user and token:
        auth.revoke_token(user["email"], token)
    keep_ops = [("clear", REMEMBER_COOKIE, "", 0)]
    st.session_state.clear()
    init_state()
    st.session_state.cookie_ops = keep_ops
    st.session_state.cookie_checked = True   # don't auto-login from the old cookie


def _cookie_token() -> Optional[str]:
    try:
        return st.context.cookies.get(REMEMBER_COOKIE)
    except Exception:
        return None


def restore_from_cookie() -> None:
    """Log in from the remember-me cookie once per browser session."""
    if current_user() or st.session_state.cookie_checked:
        return
    st.session_state.cookie_checked = True
    user = auth.user_from_token(_cookie_token())
    if user:
        st.session_state.user = user


def flash(message: str, icon: str = ":material/check_circle:") -> None:
    st.session_state.flash = (message, icon)


def show_flash() -> None:
    message = st.session_state.pop("flash", None)
    st.session_state.flash = None
    if message:
        st.toast(message[0], icon=message[1])


# ------------------------------------------------------------ navigation
def go(page: str) -> None:
    st.switch_page(PAGES[page])


def open_product(product_id: str) -> None:
    st.session_state.product_id = product_id
    go("product")


def start_tryon(product_id: str) -> None:
    st.session_state.tryon_product_id = product_id
    go("tryon")


# ------------------------------------------------------------ shop wrappers
def favorites() -> list[str]:
    user = current_user()
    return list(user.get("favorites", [])) if user else []


def is_favorite(product_id: str) -> bool:
    return product_id in favorites()


def toggle_favorite(product_id: str) -> bool:
    now_fav = shop.toggle_favorite(email(), product_id)
    refresh_user()
    return now_fav


def cart() -> list[dict]:
    user = current_user()
    return list(user.get("cart", [])) if user else []


def cart_count() -> int:
    return sum(line["qty"] for line in cart())


def add_to_cart(product_id: str, size: Optional[str], qty: int = 1, color: Optional[str] = None) -> None:
    shop.add_to_cart(email(), product_id, size, qty, color)
    refresh_user()


def saved_size(category: str = "upper_body") -> Optional[str]:
    user = current_user()
    return (user or {}).get("sizes", {}).get(category)
