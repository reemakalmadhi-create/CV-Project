"""
Checks on the person photo before it is accepted for try-on.

Uses Pillow + NumPy, and OpenCV when installed (sharpness check). These are
quality hints for the user, not model inference.
"""

from __future__ import annotations

import io
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError

try:  # OpenCV is optional; the sharpness check is skipped without it.
    import cv2  # type: ignore
except Exception:  # pragma: no cover
    cv2 = None

MAX_BYTES = 10 * 1024 * 1024
MIN_WIDTH, MIN_HEIGHT = 384, 512
ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}


@dataclass
class Check:
    label: str
    ok: bool
    blocking: bool = True   # False = warning only


@dataclass
class ImageReport:
    image: Optional[Image.Image]
    checks: list[Check] = field(default_factory=list)

    @property
    def accepted(self) -> bool:
        return self.image is not None and all(c.ok for c in self.checks if c.blocking)

    @property
    def errors(self) -> list[str]:
        return [c.label for c in self.checks if c.blocking and not c.ok]

    @property
    def warnings(self) -> list[str]:
        return [c.label for c in self.checks if not c.blocking and not c.ok]


def open_image(data: bytes) -> Image.Image:
    image = Image.open(io.BytesIO(data))
    image.load()
    return image


def sharpness(image: Image.Image) -> Optional[float]:
    """Variance of the Laplacian (higher = sharper). None without OpenCV."""
    if cv2 is None:
        return None
    gray = np.asarray(image.convert("L").resize((512, int(512 * image.height / image.width))))
    return float(cv2.Laplacian(gray, cv2.CV_64F).var())


def validate_person_photo(data: bytes) -> ImageReport:
    if len(data) > MAX_BYTES:
        return ImageReport(None, [Check("File is larger than 10 MB", False)])
    try:
        raw = open_image(data)
    except (UnidentifiedImageError, OSError):
        return ImageReport(None, [Check("File is not a readable image", False)])

    fmt = (raw.format or "").upper()
    image = ImageOps.exif_transpose(raw).convert("RGB")
    w, h = image.size
    pixels = np.asarray(image.resize((128, int(128 * h / w)))).astype(np.float32)
    brightness = float(pixels.mean())

    checks = [
        Check("JPG, PNG or WEBP format", fmt in ALLOWED_FORMATS),
        Check(f"At least {MIN_WIDTH}×{MIN_HEIGHT} px (yours: {w}×{h})", w >= MIN_WIDTH and h >= MIN_HEIGHT),
        Check("Portrait orientation (taller than wide)", h >= w * 1.1, blocking=False),
        Check("Well lit", 45 <= brightness <= 225, blocking=False),
    ]
    sharp = sharpness(image)
    if sharp is not None:
        checks.append(Check("In focus", sharp >= 40, blocking=False))
    return ImageReport(image, checks)


def to_png_bytes(image: Image.Image) -> bytes:
    buf = io.BytesIO()
    image.save(buf, format="PNG")
    return buf.getvalue()


def square_thumbnail(image: Image.Image, size: int = 256) -> Image.Image:
    return ImageOps.fit(ImageOps.exif_transpose(image).convert("RGB"), (size, size))
