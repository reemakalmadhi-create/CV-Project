"""
Account creation, login and "remember me" tokens.

Passwords are hashed with PBKDF2-HMAC-SHA256 (Python standard library),
a random 16-byte salt per user and 260,000 iterations. Plain passwords are
never stored or logged. Remember-me tokens are random 32-byte values; only
their SHA-256 hash is stored, with an expiry.

No Streamlit import here, so this module can be unit-tested directly.
"""

from __future__ import annotations

import hashlib
import hmac
import re
import secrets
import time
from datetime import datetime, timezone
from typing import Optional

from . import storage

ITERATIONS = 260_000
REMEMBER_DAYS = 30
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$")


class AuthError(ValueError):
    """Validation or credential problem with a user-facing message."""


# ------------------------------------------------------------ validation
def validate_email(email: str) -> str:
    email = (email or "").strip()
    if not email:
        raise AuthError("Please enter your email.")
    if not EMAIL_RE.match(email) or len(email) > 254:
        raise AuthError("Please enter a valid email address.")
    return email


def password_problems(password: str) -> list[str]:
    """Return the unmet password rules (empty list = OK)."""
    problems = []
    if len(password or "") < 8:
        problems.append("at least 8 characters")
    if not re.search(r"[A-Za-z]", password or ""):
        problems.append("a letter")
    if not re.search(r"\d", password or ""):
        problems.append("a number")
    return problems


def validate_name(name: str) -> str:
    name = " ".join((name or "").split())
    if len(name) < 2:
        raise AuthError("Please enter your full name.")
    if len(name) > 80:
        raise AuthError("Name is too long.")
    return name


# ------------------------------------------------------------ hashing
def hash_password(password: str, salt: Optional[bytes] = None) -> dict:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, ITERATIONS)
    return {"salt": salt.hex(), "hash": digest.hex(), "iterations": ITERATIONS}


def verify_password(password: str, stored: dict) -> bool:
    try:
        salt = bytes.fromhex(stored["salt"])
        digest = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), salt, int(stored.get("iterations", ITERATIONS))
        )
        return hmac.compare_digest(digest.hex(), stored["hash"])
    except (KeyError, ValueError, TypeError):
        return False


# ------------------------------------------------------------ accounts
def public_user(record: dict) -> dict:
    """Record without secrets — safe to keep in session state."""
    return {k: v for k, v in record.items() if k not in {"password", "remember_tokens"}}


def register(name: str, email: str, password: str, confirm: str) -> dict:
    name = validate_name(name)
    email = validate_email(email)
    problems = password_problems(password)
    if problems:
        raise AuthError("Password needs " + ", ".join(problems) + ".")
    if password != confirm:
        raise AuthError("Passwords don't match.")
    if storage.user_exists(email):
        raise AuthError("An account with this email already exists. Try logging in.")
    record = {
        "name": name,
        "email": email,
        "password": hash_password(password),
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "avatar": None,
        "favorites": [],
        "cart": [],
        "orders": [],
        "sizes": {"upper_body": None, "lower_body": None, "dresses": None},
        "tryon_history": [],
        "remember_tokens": {},
    }
    storage.create_user(record)
    return public_user(record)


def authenticate(email: str, password: str) -> dict:
    email = (email or "").strip()
    if not email or not password:
        raise AuthError("Please enter your email and password.")
    record = storage.get_user(email)
    # Same message for unknown email and wrong password (no account probing).
    if record is None or not verify_password(password, record.get("password", {})):
        raise AuthError("Incorrect email or password.")
    return public_user(record)


def change_password(email: str, current: str, new: str, confirm: str) -> None:
    record = storage.get_user(email)
    if record is None or not verify_password(current, record["password"]):
        raise AuthError("Current password is incorrect.")
    problems = password_problems(new)
    if problems:
        raise AuthError("New password needs " + ", ".join(problems) + ".")
    if new != confirm:
        raise AuthError("New passwords don't match.")

    def apply(rec: dict) -> None:
        rec["password"] = hash_password(new)
        rec["remember_tokens"] = {}  # sign out remembered devices

    storage.update_user(email, apply)


# ------------------------------------------------------------ remember me
def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def issue_remember_token(email: str) -> str:
    token = secrets.token_urlsafe(32)
    now = time.time()

    def apply(rec: dict) -> None:
        tokens = {h: exp for h, exp in rec.get("remember_tokens", {}).items() if exp > now}
        tokens[_token_hash(token)] = now + REMEMBER_DAYS * 86400
        rec["remember_tokens"] = tokens

    storage.update_user(email, apply)
    return token


def user_from_token(token: Optional[str]) -> Optional[dict]:
    if not token:
        return None
    h, now = _token_hash(token), time.time()
    record = storage.find_user_by(lambda r: r.get("remember_tokens", {}).get(h, 0) > now)
    return public_user(record) if record else None


def revoke_token(email: str, token: Optional[str]) -> None:
    if not token or not email:
        return
    h = _token_hash(token)
    try:
        storage.update_user(email, lambda rec: rec.get("remember_tokens", {}).pop(h, None))
    except KeyError:
        pass
