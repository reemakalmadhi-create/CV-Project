"""
FITTED — AI virtual try-on fashion platform (Streamlit prototype).

Run locally:   streamlit run app.py

This file is only the shell: page config, theme, navigation, login gate,
navbar, motion layer. Each page lives in pages/. The try-on model
(IDM-VTON) is NOT bundled; see model/idm_vton/README.md.
"""

from __future__ import annotations

from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parent

st.set_page_config(
    page_title="FITTED — Virtual try-on",
    page_icon=str(ROOT / "assets" / "images" / "favicon.png"),
    layout="wide",
    initial_sidebar_state="collapsed",
)

from components import navbar, splash  # noqa: E402  (after set_page_config)
from components.animations import inject_fx, inject_theme, run_cookie_ops  # noqa: E402
from utils import session  # noqa: E402

session.init_state()
session.restore_from_cookie()

P = session.PAGES
PAGES = {
    "home": st.Page(P["home"], title="Home", url_path="home", default=True),
    "login": st.Page(P["login"], title="Log in", url_path="login"),
    "signup": st.Page(P["signup"], title="Create account", url_path="signup"),
    "closet": st.Page(P["closet"], title="Closet", url_path="closet"),
    "product": st.Page(P["product"], title="Product", url_path="product"),
    "tryon": st.Page(P["tryon"], title="Virtual try-on", url_path="try-on"),
    "favorites": st.Page(P["favorites"], title="Favorites", url_path="favorites"),
    "cart": st.Page(P["cart"], title="Shopping bag", url_path="bag"),
    "profile": st.Page(P["profile"], title="My profile", url_path="profile"),
}
PUBLIC = {"login", "signup"}

page = st.navigation(list(PAGES.values()), position="hidden")
current = next((name for name, p in PAGES.items() if p is page), "home")

inject_theme()

user = session.current_user()
if user is None and current not in PUBLIC:
    st.switch_page(PAGES["login"])
if user is not None and current in PUBLIC:
    st.switch_page(PAGES["home"])

# Opening splash (fitting-room curtain) — once per visit.
splash.render_once()

# Zero-height helpers (hidden via CSS), rendered before the page so a page
# calling st.stop() can't skip them.
inject_fx()
ops, st.session_state.cookie_ops = st.session_state.cookie_ops, []
run_cookie_ops(ops)

navbar.render(current)
session.show_flash()
page.run()
