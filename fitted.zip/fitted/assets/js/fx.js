/* FITTED motion layer — runs in the Streamlit page (injected once by
   components/animations.py). Needs window.gsap; every effect is optional:
   if GSAP fails to load, content is simply shown without motion.

   Hooks (plain classes, so Streamlit's HTML sanitiser keeps them):
     .fx-hero        hero block: staggered text reveal (.fx-line children)
     .fx-reveal      fade/slide in when scrolled into view
     .fx-stagger     children fade in one after another when in view
     .ft-hero-stack  mouse-parallax on .ft-plate layers
     [class*=st-key-card-]  3D tilt + glare on hover
     .ft-stage       drag/hover to rotate the product (front/back)
     [role=dialog]   modal entrance
*/
(function () {
  "use strict";
  var W = window, D = document;
  if (W.__fittedFx && W.__fittedFx.ready) { W.__fittedFx.scan(); return; }

  var gsap = W.gsap;
  var reduced = W.matchMedia && W.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var EASE = "power3.out";

  function each(sel, fn, root) { Array.prototype.forEach.call((root || D).querySelectorAll(sel), fn); }
  function once(el, flag) { if (el.dataset[flag]) return false; el.dataset[flag] = "1"; return true; }

  // ---------------------------------------------------------- scroll reveals
  var io = ("IntersectionObserver" in W) ? new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      io.unobserve(e.target);
      var el = e.target;
      if (el.classList.contains("fx-stagger")) {
        gsap.fromTo(el.children, { autoAlpha: 0, y: 26 }, { autoAlpha: 1, y: 0, duration: .9, ease: EASE, stagger: .08, clearProps: "transform" });
      } else {
        gsap.fromTo(el, { autoAlpha: 0, y: 30 }, { autoAlpha: 1, y: 0, duration: 1, ease: EASE, clearProps: "transform" });
      }
    });
  }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 }) : null;

  function reveals() {
    each('.fx-reveal, .fx-stagger, [class*="st-key-card-"], [class*="st-key-reveal"]', function (el) {
      if (!once(el, "fxSeen")) return;
      if (!io || reduced) return;
      if (el.classList.contains("fx-stagger")) gsap.set(el.children, { autoAlpha: 0 });
      else gsap.set(el, { autoAlpha: 0 });
      io.observe(el);
    });
  }

  // ---------------------------------------------------------- hero text
  function hero() {
    each(".fx-hero", function (el) {
      if (!once(el, "fxHero") || reduced) return;
      var tl = gsap.timeline({ defaults: { ease: "expo.out" } });
      tl.from(el.querySelectorAll(".fx-eyebrow"), { autoAlpha: 0, y: 12, duration: .8 })
        .from(el.querySelectorAll(".fx-line > span"), { yPercent: 110, duration: 1.2, stagger: .1 }, "-=.5")
        .from(el.querySelectorAll(".fx-fade"), { autoAlpha: 0, y: 16, duration: .9, stagger: .08 }, "-=.8")
        .from(el.querySelectorAll(".ft-plate"), { autoAlpha: 0, y: 60, rotateX: -12, duration: 1.4, stagger: .12 }, "<-.2");
    });
  }

  // ---------------------------------------------------------- parallax
  function parallax() {
    each(".ft-hero-stack", function (stack) {
      if (!once(stack, "fxPar") || reduced) return;
      var plates = stack.querySelectorAll(".ft-plate");
      stack.parentElement.addEventListener("mousemove", function (ev) {
        var r = stack.getBoundingClientRect();
        var x = (ev.clientX - r.left) / r.width - .5, y = (ev.clientY - r.top) / r.height - .5;
        plates.forEach(function (p, i) {
          var depth = [14, 26, 14][i] || 16;
          gsap.to(p, { x: x * depth, y: y * depth * .6, rotateY: (i === 0 ? 18 : i === 2 ? -18 : 0) + x * 8, duration: 1.1, ease: "power2.out" });
        });
      });
    });
  }

  // ---------------------------------------------------------- card tilt
  function cards() {
    each('[class*="st-key-card-"]', function (card) {
      if (!once(card, "fxCard")) return;
      if (reduced) return;
      card.style.transformPerspective = "900px";
      var glare = card.querySelector(".ft-card-glare");
      card.addEventListener("mousemove", function (ev) {
        var r = card.getBoundingClientRect();
        var x = (ev.clientX - r.left) / r.width, y = (ev.clientY - r.top) / r.height;
        gsap.to(card, { rotateY: (x - .5) * 9, rotateX: (.5 - y) * 7, transformPerspective: 900, duration: .5, ease: "power2.out" });
        if (glare) { glare.style.setProperty("--gx", (x * 100) + "%"); glare.style.setProperty("--gy", (y * 100) + "%"); }
      });
      card.addEventListener("mouseleave", function () {
        gsap.to(card, { rotateY: 0, rotateX: 0, duration: .9, ease: "elastic.out(1, .6)" });
      });
    });
  }

  // ---------------------------------------------------------- product stage
  function stages() {
    each(".ft-stage", function (stage) {
      if (!once(stage, "fxStage")) return;
      var inner = stage.querySelector(".ft-stage-inner");
      if (!inner) return;
      var angle = 0, dragging = false, startX = 0, startA = 0;
      function set(a, dur) { angle = a; gsap.to(inner, { rotateY: a, duration: dur, ease: dur ? "power3.out" : "none" }); }
      stage.addEventListener("pointerdown", function (e) { dragging = true; startX = e.clientX; startA = angle; stage.setPointerCapture(e.pointerId); stage.style.cursor = "grabbing"; });
      stage.addEventListener("pointermove", function (e) {
        if (dragging) { set(startA + (e.clientX - startX) * .5, 0); return; }
        if (reduced) return;
        var r = stage.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
        gsap.to(inner, { rotateY: angle + x * 14, rotateX: -y * 8, duration: .6, ease: "power2.out" });
      });
      function end() {
        if (!dragging) return; dragging = false; stage.style.cursor = "";
        var n = ((angle % 360) + 360) % 360, snap = angle - n + (n > 90 && n < 270 ? 180 : (n >= 270 ? 360 : 0));
        set(snap, reduced ? 0 : .9);
      }
      stage.addEventListener("pointerup", end); stage.addEventListener("pointercancel", end);
      stage.addEventListener("mouseleave", function () { if (!dragging) gsap.to(inner, { rotateY: angle, rotateX: 0, duration: .8, ease: EASE }); });
      stage.addEventListener("dblclick", function () { set(angle + 180, reduced ? 0 : 1.1); });
      if (!reduced) gsap.from(inner, { rotateY: -35, autoAlpha: 0, duration: 1.3, ease: "expo.out" });
    });
  }

  // ---------------------------------------------------------- dialogs
  function dialogs() {
    each('[data-testid="stDialog"] [role="dialog"], div[role="dialog"]', function (d) {
      if (!once(d, "fxDlg") || reduced) return;
      gsap.from(d, { autoAlpha: 0, y: 24, scale: .97, duration: .55, ease: "expo.out" });
    });
  }

  // ---------------------------------------------------------- page transition
  var lastPath = null;
  function pageTransition() {
    var path = W.location.pathname;
    if (path === lastPath) return;
    var first = lastPath === null;
    lastPath = path;
    if (first || reduced) return;
    var main = D.querySelector('[data-testid="stMainBlockContainer"]') || D.querySelector(".block-container");
    if (main) gsap.fromTo(main, { autoAlpha: 0, y: 14 }, { autoAlpha: 1, y: 0, duration: .7, ease: EASE, clearProps: "transform,opacity,visibility" });
  }

  function scan() {
    if (!gsap) return;
    try { pageTransition(); hero(); reveals(); parallax(); cards(); stages(); dialogs(); } catch (err) { console.warn("[FITTED fx]", err); }
  }

  var pending = 0;
  var mo = new MutationObserver(function () {
    if (pending) return;
    pending = W.requestAnimationFrame(function () { pending = 0; scan(); });
  });
  mo.observe(D.body, { childList: true, subtree: true });

  W.__fittedFx = { ready: true, scan: scan };
  scan();
})();
