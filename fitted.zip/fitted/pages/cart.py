"""Shopping bag: lines, quantities, totals, prototype checkout."""

import html

import streamlit as st

from components.empty_state import empty_state
from utils import session, shop
from utils.catalog import FREE_SHIPPING_FROM, format_sar

st.markdown(
    '<div class="fx-hero" style="padding:1.25rem 0 1.25rem"><p class="ft-eyebrow fx-eyebrow">Shopping bag</p>'
    '<h1 class="ft-display" style="font-size:clamp(2rem,4vw,3.2rem)">'
    '<span class="ft-line-mask fx-line"><span>Your bag.</span></span></h1></div>',
    unsafe_allow_html=True,
)


@st.dialog("Confirm order")
def checkout_dialog(totals: dict) -> None:
    st.markdown(f"**Total: {format_sar(totals['total'])}** ({totals['count']} items)")
    st.info("This is a prototype: no payment is taken and nothing will be shipped. "
            "Placing the order records it in your order history.")
    if st.button("Place order", type="primary", width="stretch"):
        order = shop.place_order(session.email())
        session.refresh_user()
        session.flash(f"Order {order['id']} placed — see My profile → Orders", ":material/inventory_2:")
        st.rerun()


lines = shop.priced_lines(session.cart())
if not lines:
    empty_state("empty_cart", "Your bag is empty", "Pieces you add will wait for you here.",
                "Continue shopping", "closet", key="cart-empty")
    st.stop()

left, gap, right = st.columns([1.9, 0.1, 1], vertical_alignment="top")

with left:
    for line in lines:
        p, i = line["product"], line["index"]
        with st.container(key=f"reveal-line-{i}"):
            a, b, c, d = st.columns([0.8, 2.2, 1.1, 0.9], vertical_alignment="center")
            a.markdown(f'<div class="ft-thumb" style="background-image:url({html.escape(p["image"])})"></div>',
                       unsafe_allow_html=True)
            b.markdown(
                f'<p style="font-weight:600;margin:0">{html.escape(p["name"])}</p>'
                f'<p class="ft-small" style="margin:.2rem 0">Size {html.escape(line["size"])}'
                f'{" · " + html.escape(line["color"]) if line.get("color") else ""}</p>'
                f'<p style="margin:.2rem 0">{format_sar(p["price_sar"])}</p>',
                unsafe_allow_html=True,
            )
            qty = c.number_input("Qty", 1, shop.MAX_QTY, line["qty"], key=f"qty-line-{i}-{line['product_id']}-{line['size']}")
            if qty != line["qty"]:
                shop.set_quantity(session.email(), i, int(qty))
                session.refresh_user()
                st.rerun()
            d.markdown(f'<p style="text-align:right;font-weight:600;margin:0">{format_sar(line["line_total"])}</p>',
                       unsafe_allow_html=True)
            if d.button("Remove", key=f"rm-{i}-{line['product_id']}-{line['size']}", type="tertiary", width="stretch"):
                shop.remove_line(session.email(), i)
                session.refresh_user()
                session.flash("Removed from bag")
                st.rerun()
        st.markdown('<hr style="border:0;border-top:1px solid #E5E5E5;margin:.6rem 0">', unsafe_allow_html=True)

with right:
    totals = shop.totals(session.cart())
    with st.container(key="summary"):
        ship = "Free" if totals["shipping"] == 0 else format_sar(totals["shipping"])
        st.markdown(
            f"""<p class="ft-eyebrow">Order summary</p>
                <div class="ft-sum-row"><span>Subtotal ({totals['count']} items)</span><span>{format_sar(totals['subtotal'])}</span></div>
                <div class="ft-sum-row"><span>Shipping estimate</span><span>{ship}</span></div>
                <div class="ft-sum-row total"><span>Total</span><span>{format_sar(totals['total'])}</span></div>
                <p class="ft-small" style="margin:.8rem 0 1rem">Free delivery in Saudi Arabia on orders over
                {format_sar(FREE_SHIPPING_FROM)}. Prices include VAT.</p>""",
            unsafe_allow_html=True,
        )
        if st.button("Checkout", type="primary", width="stretch", icon=":material/lock:"):
            checkout_dialog(totals)
        if st.button("Continue shopping", width="stretch"):
            session.go("closet")
