"""Closet: the clothing catalogue — categories, colours, search, sort, product grid.

Clicking "View" on a card opens THAT piece's product details page.
"""

import streamlit as st

from components import product_card
from components.empty_state import empty_state
from utils.catalog import all_products, categories, colour_names

st.markdown(
    '<div class="fx-hero" style="padding:1.5rem 0 1.25rem"><p class="ft-eyebrow fx-eyebrow">The closet</p>'
    '<h1 class="ft-display" style="font-size:clamp(2rem,4vw,3.2rem)">'
    '<span class="ft-line-mask fx-line"><span>Everything on the rail.</span></span></h1></div>',
    unsafe_allow_html=True,
)

products = all_products()

c1, c2, c3 = st.columns([2.6, 1.3, 1.1], vertical_alignment="bottom")
with c1:
    chosen = st.pills("Category", ["All"] + categories(), default="All", key="closet-cat")
with c2:
    colours = st.multiselect("Colour", colour_names(), key="closet-colour", placeholder="Any colour")
with c3:
    sort = st.selectbox("Sort by", ["Featured", "Price: low to high", "Price: high to low", "Name"], key="closet-sort")
query = st.text_input("Search", placeholder="Search the closet — e.g. knit, oxford, olive",
                      label_visibility="collapsed", key="closet-q")

items = products
if chosen and chosen != "All":
    items = [p for p in items if p["category"] == chosen]
if colours:
    items = [p for p in items if any(c["name"] in colours for c in p.get("colors", []))]
if query.strip():
    q = query.strip().lower()
    items = [p for p in items if q in f'{p["name"]} {p.get("description", "")} {p["category"]}'.lower()]
if sort == "Price: low to high":
    items = sorted(items, key=lambda p: p["price_sar"])
elif sort == "Price: high to low":
    items = sorted(items, key=lambda p: -p["price_sar"])
elif sort == "Name":
    items = sorted(items, key=lambda p: p["name"])

st.markdown(f'<p class="ft-small" style="margin:.4rem 0 1.2rem">{len(items)} of {len(products)} pieces</p>',
            unsafe_allow_html=True)

if items:
    product_card.grid(items, prefix="closet", columns=4, show_tryon=True)
else:
    empty_state("empty_favorites", "Nothing matches", "Try clearing a filter or searching for something else.",
                key="closet-empty")
