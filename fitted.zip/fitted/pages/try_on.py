"""AI virtual try-on.

Flow: garment (from TRY ON) + uploaded person photo + category
  -> validate -> prepare inputs (resize to 768×1024)
  -> services.tryon_service.generate_tryon()  (IDM-VTON, not integrated yet)
  -> result area.

While IDM-VTON is pending, no result image is shown — only a clearly
labelled "integration pending" state. Nothing here fakes a result.
"""

import html
import time
import uuid

import streamlit as st

from components import result_viewer, upload_component
from components.animations import lottie
from services.tryon_service import (
    CATEGORY_LABELS,
    default_category,
    generate_tryon,
    is_model_ready,
    model_status,
    prepare_inputs,
)
from utils import session, shop, storage
from utils.catalog import all_products, format_sar, get_product

st.session_state.setdefault("tryon_outcome", None)

ready = is_model_ready()
dot = "ok" if ready else ""
label = "IDM-VTON connected" if ready else "IDM-VTON integration pending"
st.markdown(
    f"""<div class="fx-hero" style="padding:1.25rem 0 1.5rem">
          <p class="ft-eyebrow fx-eyebrow">Virtual try-on</p>
          <h1 class="ft-display" style="font-size:clamp(2rem,4vw,3.3rem)">
            <span class="ft-line-mask fx-line"><span>See it on you.</span></span></h1>
          <p class="fx-fade" style="margin-top:.9rem"><span class="ft-status"><span class="ft-dot {dot}"></span>{label}</span></p>
        </div>""",
    unsafe_allow_html=True,
)

col_photo, col_garment, col_result = st.columns([1, 1, 1.15], gap="large")

# ------------------------------------------------------------------ 01 photo
with col_photo:
    st.markdown('<div class="ft-step"><b>01</b><span>Your photo</span></div>', unsafe_allow_html=True)
    person = upload_component.render()

# ------------------------------------------------------------------ 02 garment
with col_garment:
    st.markdown('<div class="ft-step"><b>02</b><span>Garment</span></div>', unsafe_allow_html=True)
    products = all_products()
    ids = [p["id"] for p in products]
    current = get_product(st.session_state.get("tryon_product_id"))
    choice = st.selectbox(
        "Garment", ids, index=ids.index(current["id"]) if current else None,
        format_func=lambda i: get_product(i)["name"], placeholder="Choose a garment…",
        label_visibility="collapsed", key="tryon-garment",
    )
    if choice != (current or {}).get("id"):
        st.session_state.tryon_product_id = choice
        st.session_state.tryon_outcome = None
    product = get_product(choice)

    if product:
        st.markdown(
            f"""<div class="ft-frame"><span class="ft-frame-label">Selected garment</span>
                  <img src="{html.escape(product['image'])}" alt="{html.escape(product['name'])}"></div>
                <p style="margin:.7rem 0 0;font-weight:600">{html.escape(product['name'])}</p>
                <p class="ft-small" style="margin:.1rem 0 .8rem">{format_sar(product['price_sar'])} · {html.escape(product['category'])}</p>""",
            unsafe_allow_html=True,
        )
        cats = list(CATEGORY_LABELS)
        category = st.selectbox(
            "Garment category", cats, index=cats.index(default_category(product)),
            format_func=CATEGORY_LABELS.get, key=f"tryon-cat-{product['id']}",
            help="Which part of your photo the model should dress.",
        )
    else:
        category = None
        st.markdown(
            "<div class='ft-frame'><div class='ft-frame-empty'><strong>No garment selected</strong>"
            "Choose one above, or press <b>Try on</b> on any product.</div></div>",
            unsafe_allow_html=True,
        )
        if st.button("Browse the closet", width="stretch"):
            session.go("closet")

# ------------------------------------------------------------------ 03 generate + result
with col_result:
    st.markdown('<div class="ft-step"><b>03</b><span>Your look</span></div>', unsafe_allow_html=True)

    clicked = st.button("Generate try-on", type="primary", icon=":material/auto_awesome:",
                        width="stretch", key="tryon-generate")
    if clicked:
        missing = [name for name, value in (("your photo", person), ("a garment", product)) if value is None]
        if missing:
            st.warning("Please add " + " and ".join(missing) + " before generating.")
        else:
            slot = st.empty()
            with slot.container():
                lottie("processing", height=210, caption="Preparing your virtual try-on experience…")
            started = time.perf_counter()
            prepared = prepare_inputs(person, product)          # real resize, no AI
            outcome = generate_tryon(prepared.person, prepared.garment, product, category)
            # keep the loader on screen long enough to be read, never longer
            time.sleep(max(0.0, 1.2 - (time.perf_counter() - started)))
            slot.empty()

            if outcome.status == "ok" and outcome.image is not None:
                folder = storage.user_upload_dir(session.email())
                filename = f"tryon-{product['id']}-{uuid.uuid4().hex[:8]}.png"
                outcome.image.save(folder / filename)
                shop.add_tryon_result(session.email(), product["id"], filename)
                session.refresh_user()
            st.session_state.tryon_outcome = {
                "status": outcome.status, "message": outcome.message, "detail": outcome.detail,
                "image": outcome.image, "product_id": product["id"], "category": category,
                "person_size": prepared.person.size,
                "garment_size": prepared.garment.size if prepared.garment else None,
                "garment_error": prepared.garment_error,
            }

    result = st.session_state.tryon_outcome
    if result and product and result["product_id"] != product["id"]:
        result = st.session_state.tryon_outcome = None

    if result and result["status"] == "pending":
        g = (f"✓ Garment photo — {result['garment_size'][0]}×{result['garment_size'][1]}"
             if result["garment_size"] else
             "• Garment photo — will be fetched at inference time (it couldn't be downloaded right now)")
        st.markdown(
            f"""<div class="ft-pending">
                  <p class="ft-status" style="margin-bottom:.7rem"><span class="ft-dot"></span>Integration pending</p>
                  <h4>Your images are ready for AI processing.</h4>
                  <p>✓ Your photo — resized to {result['person_size'][0]}×{result['person_size'][1]}</p>
                  <p>{html.escape(g)}</p>
                  <p>✓ Category — <code>{html.escape(result['category'])}</code></p>
                  <p style="margin-top:.8rem;color:#111">IDM-VTON integration will be connected in the next
                  development phase. No try-on image has been generated.</p>
                </div>""",
            unsafe_allow_html=True,
        )
        with st.expander("Technical status"):
            st.code(result["detail"] or model_status(), language=None)
        st.write("")
    elif result and result["status"] == "error":
        lottie("error", height=120)
        st.error(result["message"])
        if result["detail"]:
            st.caption(result["detail"])

    result_viewer.render(
        result["image"] if result and result["status"] == "ok" else None,
        person,
        product,
    )
