"""Create an account."""

import streamlit as st

from components.auth_layout import logo
from utils import authentication as auth
from utils import session

# Centered sign-in card (no side picture)
st.markdown('<div style="height:6vh"></div>', unsafe_allow_html=True)
_, middle, _ = st.columns([1, 1.15, 1])

with middle:
    logo()
    st.markdown('<div style="text-align:center"><p class="ft-eyebrow">Join FITTED</p>'
                '<h1 class="ft-title">Create your account</h1></div>',
                unsafe_allow_html=True)
    st.write("")
    with st.form("signup-form", border=False):
        name = st.text_input("Full name", autocomplete="name")
        email = st.text_input("Email", placeholder="you@example.com", autocomplete="email")
        password = st.text_input("Password", type="password", autocomplete="new-password",
                                 help="At least 8 characters, with a letter and a number.")
        confirm = st.text_input("Confirm password", type="password", autocomplete="new-password")
        submitted = st.form_submit_button("Create account", type="primary", width="stretch")
    st.caption("Passwords are stored as salted PBKDF2-SHA256 hashes, never in plain text.")
    if submitted:
        try:
            user = auth.register(name, email, password, confirm)
        except auth.AuthError as exc:
            st.error(str(exc))
        else:
            session.login(user, remember=False)
            st.session_state.new_member = True
            session.flash(f"Welcome to FITTED, {user['name'].split()[0]}")
            st.rerun()

    st.page_link(session.PAGES["login"], label="Already have an account? Log in →")
