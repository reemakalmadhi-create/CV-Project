"""My profile: details, avatar, saved sizes, try-on history, orders, settings."""

import base64
import html
from datetime import datetime

import streamlit as st

from components.animations import lottie
from utils import authentication as auth
from utils import session, shop, storage
from utils.catalog import SIZES, format_sar, get_product
from utils.images import open_image, square_thumbnail

user = session.refresh_user()
if user is None:
    session.go("login")
email = user["email"]
folder = storage.user_upload_dir(email)


def avatar_html(size: int = 112) -> str:
    path = folder / user["avatar"] if user.get("avatar") else None
    if path and path.is_file():
        data = base64.b64encode(path.read_bytes()).decode()
        return f'<img class="ft-avatar" style="width:{size}px;height:{size}px" src="data:image/png;base64,{data}" alt="">'
    initials = "".join(w[0] for w in user["name"].split()[:2]).upper()
    return f'<div class="ft-avatar" style="width:{size}px;height:{size}px">{html.escape(initials)}</div>'


def nice_date(iso: str) -> str:
    try:
        return datetime.fromisoformat(iso).strftime("%d %b %Y")
    except (TypeError, ValueError):
        return iso or ""


# ------------------------------------------------------------------ header
a, b = st.columns([0.18, 1], vertical_alignment="center")
a.markdown(avatar_html(), unsafe_allow_html=True)
b.markdown(
    f"""<div class="fx-hero"><p class="ft-eyebrow fx-eyebrow">My profile</p>
        <h1 class="ft-title"><span class="ft-line-mask fx-line"><span>{html.escape(user['name'])}</span></span></h1>
        <p class="ft-small fx-fade">{html.escape(email)} · Member since {nice_date(user.get('created_at'))}</p></div>""",
    unsafe_allow_html=True,
)
st.write("")

t_profile, t_sizes, t_history, t_orders, t_settings = st.tabs(
    ["Profile", "Saved sizes", "Try-on history", "Orders", "Account settings"])

# ------------------------------------------------------------------ profile
with t_profile:
    left, right = st.columns([1.3, 1], gap="large")
    with left:
        with st.form("edit-profile"):
            st.markdown("**Edit profile**")
            name = st.text_input("Full name", value=user["name"])
            new_email = st.text_input("Email", value=email)
            if st.form_submit_button("Save changes", type="primary"):
                try:
                    clean_name = auth.validate_name(name)
                    clean_email = auth.validate_email(new_email)
                    if storage.key_for(clean_email) != storage.key_for(email):
                        storage.rename_user(email, clean_email)
                        st.session_state.user["email"] = clean_email
                    storage.update_user(clean_email, lambda r: r.update(name=clean_name))
                    session.refresh_user()
                    session.flash("Profile updated")
                    st.rerun()
                except (auth.AuthError, ValueError) as exc:
                    st.error(str(exc))
    with right:
        st.markdown("**Profile image**")
        photo = st.file_uploader("Upload a square-ish photo (JPG/PNG/WEBP, max 5 MB)",
                                 type=["jpg", "jpeg", "png", "webp"], key="avatar-up")
        if photo is not None:
            data = photo.getvalue()
            if len(data) > 5 * 1024 * 1024:
                st.error("That file is larger than 5 MB.")
            else:
                try:
                    thumb = square_thumbnail(open_image(data))
                except Exception:
                    st.error("That file isn't a readable image.")
                else:
                    st.image(thumb, width=140)
                    if st.button("Use this photo", type="primary"):
                        thumb.save(folder / "avatar.png")
                        storage.update_user(email, lambda r: r.update(avatar="avatar.png"))
                        session.flash("Profile image updated")
                        st.rerun()
        if user.get("avatar") and st.button("Remove profile image", type="tertiary"):
            (folder / "avatar.png").unlink(missing_ok=True)
            storage.update_user(email, lambda r: r.update(avatar=None))
            st.rerun()

# ------------------------------------------------------------------ sizes
with t_sizes:
    st.caption("Used to pre-select your size on product pages and for quick add-to-bag from Favorites.")
    sizes = user.get("sizes", {})
    opts = [None] + SIZES
    c1, c2, c3 = st.columns(3)
    upper = c1.selectbox("Tops", opts, index=opts.index(sizes.get("upper_body")),
                         format_func=lambda v: v or "Not set")
    lower = c2.selectbox("Bottoms", opts, index=opts.index(sizes.get("lower_body")),
                         format_func=lambda v: v or "Not set")
    dresses = c3.selectbox("Dresses & long coats", opts, index=opts.index(sizes.get("dresses")),
                           format_func=lambda v: v or "Not set")
    if st.button("Save sizes", type="primary"):
        shop.save_sizes(email, {"upper_body": upper, "lower_body": lower, "dresses": dresses})
        session.refresh_user()
        session.flash("Sizes saved")
        st.rerun()

# ------------------------------------------------------------------ try-on history
with t_history:
    history = user.get("tryon_history", [])
    if not history:
        lottie("empty_favorites", height=130)
        st.markdown(
            "<div class='ft-empty'><h3>No try-on results yet</h3><p>Real IDM-VTON results will be saved here "
            "once the model is connected and you generate a look.</p></div>",
            unsafe_allow_html=True,
        )
    else:
        cols = st.columns(4)
        for i, entry in enumerate(history):
            path = folder / entry["image"]
            product = get_product(entry["product_id"])
            with cols[i % 4]:
                if path.is_file():
                    st.image(str(path), width="stretch")
                st.caption(f"{product['name'] if product else entry['product_id']} · {nice_date(entry['created_at'])}")

# ------------------------------------------------------------------ orders
with t_orders:
    orders = user.get("orders", [])
    if not orders:
        st.markdown("<div class='ft-empty'><h3>No orders yet</h3><p>Orders you place appear here.</p></div>",
                    unsafe_allow_html=True)
    for order in orders:
        with st.expander(f"{order['id']} · {nice_date(order['created_at'])} · {format_sar(order['total'])}"):
            for item in order["items"]:
                st.markdown(f"- {item['name']} — size {item['size']} × {item['qty']} · "
                            f"{format_sar(item['price_sar'] * item['qty'])}")
            st.caption(f"Subtotal {format_sar(order['subtotal'])} · Shipping "
                       f"{format_sar(order['shipping'])} · {order['status']}")

# ------------------------------------------------------------------ settings
with t_settings:
    left, right = st.columns(2, gap="large")
    with left:
        with st.form("change-password", clear_on_submit=True):
            st.markdown("**Change password**")
            cur = st.text_input("Current password", type="password")
            new = st.text_input("New password", type="password", help="At least 8 characters, a letter and a number.")
            conf = st.text_input("Confirm new password", type="password")
            if st.form_submit_button("Update password", type="primary"):
                try:
                    auth.change_password(email, cur, new, conf)
                    session.flash("Password updated — remembered devices were signed out")
                    st.rerun()
                except auth.AuthError as exc:
                    st.error(str(exc))
        if st.button("Sign out of all devices", icon=":material/devices:"):
            storage.update_user(email, lambda r: r.update(remember_tokens={}))
            session.logout()
            st.rerun()
    with right:
        st.markdown("**Delete account**")
        st.caption("Permanently removes your profile, bag, favorites, orders and saved images. This can't be undone.")
        confirm = st.text_input("Type DELETE to confirm", key="del-confirm")
        if st.button("Delete my account", disabled=confirm.strip() != "DELETE"):
            for f in folder.glob("*"):
                f.unlink(missing_ok=True)
            storage.delete_user(email)
            session.logout()
            st.rerun()
