"""Product details: 3D stage, sizes, size guide, quantity, Try on / Add to bag."""

import html

import pandas as pd
import streamlit as st

from components import product_card
from utils import session
from utils.catalog import SIZE_GUIDE, SIZES, all_products, format_sar, get_product

# Which product? Session first (in-app navigation), then ?id= (refresh / shared link).
pid = st.session_state.get("product_id") or st.query_params.get("id")
product = get_product(pid)
if product is None:
    st.markdown('<h1 class="ft-title">Product not found</h1>', unsafe_allow_html=True)
    st.write("This piece may have left the rail.")
    if st.button("Back to the closet", type="primary"):
        session.go("closet")
    st.stop()

st.session_state.product_id = product["id"]
st.query_params["id"] = product["id"]
pid = product["id"]

if st.button("Back to closet", type="tertiary", icon=":material/arrow_back:"):
    session.go("closet")

left, gap, right = st.columns([1.15, 0.08, 1], vertical_alignment="top")

# ------------------------------------------------------------------ stage
with left:
    front = html.escape(product["image"])
    back = html.escape(product.get("backImage") or product["image"])
    st.markdown(
        f"""<div class="ft-stage" title="Drag to turn">
              <div class="ft-stage-inner">
                <div class="ft-stage-face"><img src="{front}" alt="{html.escape(product['name'])} — front"></div>
                <div class="ft-stage-face back"><img src="{back}" alt="{html.escape(product['name'])} — back"></div>
              </div>
              <div class="ft-stage-hint">Drag to turn · double-click for the back</div>
            </div>""",
        unsafe_allow_html=True,
    )

# ------------------------------------------------------------------ details
with right:
    st.markdown(
        f"""<div class="fx-hero">
              <p class="ft-eyebrow fx-eyebrow">{html.escape(product['category'])}</p>
              <h1 class="ft-title"><span class="ft-line-mask fx-line"><span>{html.escape(product['name'])}</span></span></h1>
              <p class="ft-price fx-fade">{format_sar(product['price_sar'])}</p>
              <p class="ft-muted fx-fade" style="line-height:1.65">{html.escape(product.get('description', ''))}</p>
              <div class="fx-fade">{''.join(f'<span class="ft-detail-chip">{html.escape(d)}</span>' for d in product.get('details', []))}</div>
            </div>""",
        unsafe_allow_html=True,
    )

    colours = product.get("colors", [])
    if len(colours) > 1:
        colour = st.radio("Colour", [c["name"] for c in colours], horizontal=True, key=f"colour-{pid}")
    else:
        colour = colours[0]["name"] if colours else None
        st.markdown(
            f'<p class="ft-small" style="margin:1rem 0 .3rem">COLOUR</p>'
            f'<div style="display:flex;align-items:center;gap:.6rem">{product_card.swatches(product, large=True)}'
            f'<span>{html.escape(colour or "")}</span></div>',
            unsafe_allow_html=True,
        )

    saved = session.saved_size(product.get("tryon_category", "upper_body"))
    sizes = product.get("sizes", SIZES)
    size = st.segmented_control(
        "Size", sizes, default=saved if saved in sizes else None, key=f"size-{pid}",
        help="Pre-selected from your saved size" if saved in sizes else None,
    )
    with st.popover("Size guide", icon=":material/straighten:"):
        st.markdown("**Body measurements (cm)** — regular fit. Between sizes? Size up for a relaxed look.")
        st.dataframe(pd.DataFrame(SIZE_GUIDE, columns=["Size", "Chest", "Length", "Sleeve"]),
                     hide_index=True, width="stretch")

    qty = st.number_input("Quantity", min_value=1, max_value=10, value=1, step=1, key=f"qty-{pid}")

    a, b = st.columns(2)
    if a.button("Try on", type="primary", icon=":material/auto_awesome:", width="stretch", key="pd-try"):
        session.start_tryon(pid)
    if b.button("Add to bag", icon=":material/shopping_bag:", width="stretch", key="pd-add"):
        if not size:
            st.warning("Please select a size first.")
        else:
            session.add_to_cart(pid, size, int(qty), colour)
            session.flash(f"Added to bag — {product['name']} · {size} × {int(qty)}", ":material/shopping_bag:")
            st.rerun()

    fav = session.is_favorite(pid)
    if st.button("Saved to favorites" if fav else "Save to favorites", type="tertiary",
                 icon=":material/favorite:" if fav else ":material/favorite_border:", key="pd-fav"):
        session.toggle_favorite(pid)
        st.rerun()

    st.markdown(
        '<p class="ft-small" style="margin-top:1rem">Free delivery in Saudi Arabia on orders over SAR 500 · '
        'Returns within 14 days</p>',
        unsafe_allow_html=True,
    )

# ------------------------------------------------------------------ more
others = [p for p in all_products() if p["id"] != pid]
same = [p for p in others if p["category"] == product["category"]]
more = (same + [p for p in others if p not in same])[:4]
st.markdown('<hr class="ft-rule"><div class="fx-reveal"><p class="ft-eyebrow">You may also like</p></div>',
            unsafe_allow_html=True)
product_card.grid(more, prefix="more", columns=4)
