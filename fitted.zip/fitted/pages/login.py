"""Log in."""

import streamlit as st

from components.auth_layout import logo
from utils import authentication as auth
from utils import session


@st.dialog("Reset your password")
def forgot_password() -> None:
    email = st.text_input("Account email", placeholder="you@example.com")
    if st.button("Send reset link", type="primary", width="stretch"):
        try:
            auth.validate_email(email)
        except auth.AuthError as exc:
            st.error(str(exc))
            return
        st.info(
            "Password-reset emails aren't connected in this prototype, so no email was sent. "
            "Once an email service is configured (see README → *Password reset*), a one-time "
            "reset link will be sent to this address."
        )


# Centered sign-in card (no side picture)
st.markdown('<div style="height:6vh"></div>', unsafe_allow_html=True)
_, middle, _ = st.columns([1, 1.15, 1])

with middle:
    logo()
    st.markdown('<div style="text-align:center"><p class="ft-eyebrow">Welcome back</p>'
                '<h1 class="ft-title">Log in to your closet</h1></div>',
                unsafe_allow_html=True)
    st.write("")
    with st.form("login-form", border=False):
        email = st.text_input("Email", placeholder="you@example.com", autocomplete="email")
        password = st.text_input("Password", type="password", autocomplete="current-password",
                                 help="Use the eye icon to show or hide your password.")
        remember = st.checkbox("Remember me for 30 days")
        submitted = st.form_submit_button("Log in", type="primary", width="stretch")
    if submitted:
        try:
            user = auth.authenticate(email, password)
        except auth.AuthError as exc:
            st.error(str(exc))
        else:
            session.login(user, remember)
            session.flash(f"Welcome back, {user['name'].split()[0]}")
            st.rerun()

    a, b = st.columns(2)
    if a.button("Forgot password?", type="tertiary"):
        forgot_password()
    with b:
        st.page_link(session.PAGES["signup"], label="Create an account →")
