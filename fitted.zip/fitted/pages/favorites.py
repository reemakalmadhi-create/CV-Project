"""Favorites: saved pieces — view, try on, add to bag, remove."""


import streamlit as st

from components import product_card
from components.empty_state import empty_state
from utils import session
from utils.catalog import get_product

st.markdown(
    '<div class="fx-hero" style="padding:1.25rem 0 1.25rem"><p class="ft-eyebrow fx-eyebrow">Favorites</p>'
    '<h1 class="ft-display" style="font-size:clamp(2rem,4vw,3.2rem)">'
    '<span class="ft-line-mask fx-line"><span>Saved for later.</span></span></h1></div>',
    unsafe_allow_html=True,
)

saved = [p for p in (get_product(i) for i in session.favorites()) if p]

if not saved:
    empty_state("empty_favorites", "No favorites yet",
                "Tap the heart on any piece to keep it here.", "Explore the closet", "closet", key="fav-empty")
else:
    st.markdown(f'<p class="ft-small" style="margin-bottom:1.2rem">{len(saved)} saved</p>', unsafe_allow_html=True)
    for start in range(0, len(saved), 4):
        cols = st.columns(4, gap="medium")
        for col, product in zip(cols, saved[start:start + 4]):
            pid = product["id"]
            with col, st.container(key=f"card-fav-{pid}"):
                st.markdown(
                    product_card.media_html(product, product["category"]) + product_card.card_text(product),
                    unsafe_allow_html=True,
                )
                a, b = st.columns(2, gap="small")
                if a.button("View", key=f"fav-view-{pid}", width="stretch"):
                    session.open_product(pid)
                if b.button("Try on", key=f"fav-try-{pid}", type="primary", width="stretch"):
                    session.start_tryon(pid)
                c, d = st.columns(2, gap="small")
                size = session.saved_size(product.get("tryon_category", "upper_body"))
                if c.button("Add to bag", key=f"fav-add-{pid}", width="stretch",
                            help=f"Adds your saved size ({size})" if size else "Choose a size on the product page"):
                    if size:
                        session.add_to_cart(pid, size, 1)
                        session.flash(f"Added to bag — {product['name']} · {size}", ":material/shopping_bag:")
                        st.rerun()
                    else:
                        session.flash("Choose a size to add this piece to your bag", ":material/straighten:")
                        session.open_product(pid)
                if d.button("Remove", key=f"fav-rm-{pid}", type="tertiary", width="stretch"):
                    session.toggle_favorite(pid)
                    session.flash("Removed from favorites")
                    st.rerun()
