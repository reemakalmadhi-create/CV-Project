"""Home: personalised greeting, editorial hero, clothing rail, featured pieces, how try-on works."""

import html

import streamlit as st

from components import product_card
from components.clothing_rail import clothing_rail
from services.tryon_service import is_model_ready
from utils import session
from utils.catalog import all_products

user = session.current_user()
first = html.escape(user["name"].split()[0])
greeting = "Welcome" if st.session_state.get("new_member") else "Welcome back"
products = all_products()
# ------------------------------------------------------------------ welcome (top of the page, compact)
left, right = st.columns([3, 1.9], vertical_alignment="bottom")
with left:
    st.markdown(
        f"""<section class="fx-hero" style="padding:.75rem 0 0">
              <p class="ft-eyebrow fx-eyebrow" style="margin-bottom:.4rem">FITTED · New season</p>
              <h1 class="ft-title" style="font-size:clamp(1.5rem,2.6vw,2.1rem);margin:0">
                <span class="ft-line-mask fx-line"><span>{greeting}, <em style="font-weight:300">{first}.</em></span></span></h1>
              <p class="ft-muted fx-fade" style="margin:.35rem 0 0;font-size:.95rem">Your style, your fit, your way.</p>
            </section>""",
        unsafe_allow_html=True,
    )
with right:
    a, b = st.columns(2, gap="small")
    if a.button("Explore collection", type="primary", width="stretch"):
        session.go("closet")
    if b.button("Virtual try-on", width="stretch"):
        session.go("tryon")

# ------------------------------------------------------------------ the rail (ClothingRailHero)
event = clothing_rail(
    products,
    eyebrow="New season · Ten pieces on the rail",
    heading="A clothing rail you can handle, right on the page.",
    caption="Brush along the rail, slide a hanger, click a piece to see its details.",
    action_label="Shop the edit",
    details_label="",
    lift_dialog=False,          # click -> straight to the product details page
    autoplay=True,
    key="home-rail",
)
if event and event.get("nonce") != st.session_state.get("home_rail_nonce"):
    st.session_state.home_rail_nonce = event.get("nonce")
    if event.get("id"):
        session.open_product(event["id"])   # -> details of the SAME piece

# ------------------------------------------------------------------ featured
st.markdown(
    '<div class="fx-reveal" style="margin-top:3rem"><p class="ft-eyebrow">The edit</p>'
    '<h2 class="ft-title">Picked for this week</h2></div>',
    unsafe_allow_html=True,
)
st.write("")
product_card.grid(products[:4], prefix="home", columns=4, show_tryon=True)

# ------------------------------------------------------------------ how try-on works
ready = is_model_ready()
status = ('<span class="ft-status"><span class="ft-dot ok"></span>IDM-VTON connected</span>' if ready else
          '<span class="ft-status"><span class="ft-dot"></span>IDM-VTON integration pending</span>')
st.markdown(
    f"""
<hr class="ft-rule">
<div class="fx-reveal"><p class="ft-eyebrow">Virtual try-on</p>
<h2 class="ft-title">See it on you before it's yours</h2><p style="margin:.6rem 0 1.6rem">{status}</p></div>
<div class="fx-stagger" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:2rem">
  <div><p class="ft-eyebrow">01</p><h4>Choose a piece</h4><p class="ft-muted">Open any product and press <b>Try on</b>.
     The garment photo travels with you.</p></div>
  <div><p class="ft-eyebrow">02</p><h4>Upload your photo</h4><p class="ft-muted">A clear, front-facing full-body photo.
     We check size, light and focus before it's used.</p></div>
  <div><p class="ft-eyebrow">03</p><h4>Generate</h4><p class="ft-muted">IDM-VTON, a diffusion model for virtual
     try-on, will dress your photo in the garment.</p></div>
</div>""",
    unsafe_allow_html=True,
)
