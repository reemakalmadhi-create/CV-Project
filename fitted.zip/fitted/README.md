# FITTED — AI virtual try-on fashion platform (prototype)

A premium fashion-tech storefront built with **Python + Streamlit**, with
**GSAP** motion, **CSS 3D** depth and **Lottie** states. The virtual try-on is
designed around **IDM-VTON**, which is **not included yet**. Generating a
try-on shows *"IDM-VTON integration pending"*. No result is faked.

## Run locally

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

Create an account on the sign-up page. Data is stored in `data/runtime/`.

Tests for the core logic (no Streamlit needed): `python tests/test_core.py`

## What's in it

| Page | Highlights |
|---|---|
| Splash | Once per visit: a fitting-room curtain — FITTED writes in, a line fills, the curtain draws open and the site appears (pure CSS, ~3.3 s, respects reduced motion) |
| Log in / Sign up | Validation, show/hide password, *remember me* (30-day cookie), forgot-password dialog |
| Home | "Welcome back, *name*" hero (GSAP text reveal, 3D parallax plates), the **clothing rail** from the prompt (click lifts a piece; *View details* opens its product page), featured edit, how try-on works |
| Closet | Category pills, colour filter, search, sort, grid of 3D-tilt cards (View / Try on / ♡); *View* opens that piece's details |
| Product | Drag-to-turn 3D stage (front/back), colours, XS–XXL size picker (required), size guide, quantity, **Try on**, **Add to bag** |
| Virtual try-on | Drag & drop upload, preview, quality checks (size, orientation, light, focus via OpenCV), remove/replace, garment preview, category, **Generate**, Lottie loader, honest pending state, result area with before/after slider + download (enabled only for real results) |
| Favorites | View, try on, add to bag (uses your saved size), remove, empty state |
| Bag | Quantities, remove, subtotal, shipping estimate (free over SAR 500), total, prototype checkout |
| My profile | Avatar, edit name/email, saved sizes, try-on history, orders, change password, sign out everywhere, delete account |

## Project structure

```
app.py                     shell: page config, theme, navigation, login gate, navbar
pages/                     one file per page (registered with st.navigation)
components/
  navbar.py  product_card.py  upload_component.py  result_viewer.py
  empty_state.py  auth_layout.py
  animations.py            theme CSS, GSAP injector, Lottie player, cookie writer
  clothing_rail/           interactive rail (plain-JS Streamlit component, no build)
    static/                index.html, rail.js, rail.css  ← used at runtime
    frontend/              original React/TSX source, kept for reference only
services/tryon_service.py  the ONLY bridge between the UI and the model
model/idm_vton/            IDM-VTON integration layer (placeholders, see its README)
assets/css|js|lottie|images
data/products/catalog.json product catalogue (prices in SAR)
utils/                     authentication, session, storage, shop, catalog, images
tests/test_core.py
```

## Design notes

- **No React, no Node build.** The clothing rail was ported from the React
  component to plain JavaScript and talks to Streamlit through the component
  message protocol, so it deploys to Streamlit Cloud as is.
- **GSAP / Lottie** load from cdnjs in the visitor's browser. If they can't load,
  the site still works and just shows no motion (Lottie spots show a static icon).
  Motion respects *prefers-reduced-motion*.
- **CSS 3D** is used for depth and tilt only. It isn't a 3D garment model.
- **Passwords**: PBKDF2-HMAC-SHA256, per-user salt, 260k iterations. Remember-me
  tokens are random and only their hash is stored.

## IDM-VTON integration (later)

Everything model-related lives in `model/idm_vton/` and is reached only through
`services/tryon_service.py`. Steps to connect it are in
[`model/idm_vton/README.md`](model/idm_vton/README.md). Short version: add the
files to `vendor/`, `weights/` and `ckpt/`, implement the functions marked
**NOT IMPLEMENTED**, then set `INTEGRATED = True`. No page code changes.

## Deploy to Streamlit Community Cloud

1. Push this folder to a GitHub repo (`.gitignore` keeps runtime data, secrets and model files out).
2. On share.streamlit.io → **New app** → pick the repo, branch, and `app.py`.
3. Python 3.11+ is recommended. Only `requirements.txt` is installed, with no
   PyTorch and no weights, so startup stays fast.
4. Optional environment variables / secrets (App settings → Secrets):

| Variable | Purpose | Default |
|---|---|---|
| `FITTED_DATA_DIR` | Where accounts and uploads are stored | `data/runtime` |
| `IDM_VTON_WEIGHTS_DIR`, `IDM_VTON_SOURCE_DIR`, `IDM_VTON_CKPT_DIR` | Model file locations | `model/idm_vton/*` |
| `IDM_VTON_DEVICE` | `auto` / `cuda` / `cpu` | `auto` |

**Important limitations of the free cloud tier**
- The disk is **not persistent**, so accounts, bags and orders reset when the app
  restarts. For a real deployment, replace `utils/storage.py` (one small module)
  with a database such as Postgres, Supabase or Firestore.
- There is **no GPU**. IDM-VTON needs a GPU with roughly 16 GB+ VRAM. Run inference
  on a separate GPU machine (or run the whole app there) and point
  `services/tryon_service.generate_tryon` at it.

## Password reset

The *Forgot password* dialog is wired but doesn't send email. To enable it, add
an email provider (SMTP or a transactional service): generate a one-time token
the same way remember-me tokens are generated in `utils/authentication.py`,
email a link with it, and add a "set new password" step that checks the token.
