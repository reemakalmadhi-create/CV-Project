"""Core logic tests (no Streamlit needed):  python -m pytest tests  or  python tests/test_core.py"""
import io
import os
import sys
import tempfile
from pathlib import Path

os.environ["FITTED_DATA_DIR"] = tempfile.mkdtemp(prefix="fitted-test-")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PIL import Image  # noqa: E402

from model.idm_vton import IDMVTONNotIntegratedError  # noqa: E402
from model.idm_vton.inference import generate_tryon as model_generate  # noqa: E402
from services import tryon_service  # noqa: E402
from utils import authentication as auth  # noqa: E402
from utils import shop, storage  # noqa: E402
from utils.catalog import all_products, categories, format_sar, get_product  # noqa: E402
from utils.images import validate_person_photo  # noqa: E402


def expect(exc, fn, *a):
    try:
        fn(*a)
    except exc as e:
        return e
    raise AssertionError(f"{fn.__name__} did not raise {exc.__name__}")


def test_auth_flow():
    user = auth.register("Reem Test", "Reem@Example.com", "secret123", "secret123")
    assert "password" not in user
    raw = storage.get_user("reem@example.com")
    assert raw["password"]["hash"] and "secret123" not in str(raw)
    assert auth.authenticate("REEM@example.com", "secret123")["name"] == "Reem Test"
    assert "Incorrect" in str(expect(auth.AuthError, auth.authenticate, "reem@example.com", "wrong999"))
    assert "Incorrect" in str(expect(auth.AuthError, auth.authenticate, "nobody@example.com", "secret123"))
    expect(auth.AuthError, auth.register, "Reem", "reem@example.com", "secret123", "secret123")  # duplicate
    expect(auth.AuthError, auth.register, "Al", "x@y.co", "short1", "short1")                  # weak
    expect(auth.AuthError, auth.register, "Al Bo", "x@y.co", "secret123", "secret124")          # mismatch
    expect(auth.AuthError, auth.register, "Al Bo", "not-an-email", "secret123", "secret123")
    token = auth.issue_remember_token("reem@example.com")
    assert auth.user_from_token(token)["email"] == "Reem@Example.com"
    assert auth.user_from_token("bogus") is None
    auth.revoke_token("reem@example.com", token)
    assert auth.user_from_token(token) is None
    auth.change_password("reem@example.com", "secret123", "newpass456", "newpass456")
    auth.authenticate("reem@example.com", "newpass456")


def test_shop_flow():
    auth.register("Shop User", "shop@example.com", "secret123", "secret123")
    e = "shop@example.com"
    assert shop.toggle_favorite(e, "bone-tee") is True
    assert shop.toggle_favorite(e, "bone-tee") is False
    expect(ValueError, shop.add_to_cart, e, "bone-tee", None, 1)          # no size
    shop.add_to_cart(e, "bone-tee", "M", 2)
    shop.add_to_cart(e, "bone-tee", "M", 1)                               # merges
    shop.add_to_cart(e, "breton", "L", 1)
    cart = storage.get_user(e)["cart"]
    assert len(cart) == 2 and cart[0]["qty"] == 3
    t = shop.totals(cart)
    assert t["subtotal"] == 180 * 3 + 220 and t["shipping"] == 0 and t["total"] == 760
    shop.set_quantity(e, 1, 0)
    t = shop.totals(storage.get_user(e)["cart"])
    assert t["subtotal"] == 540 and t["shipping"] == 0
    shop.set_quantity(e, 0, 1)
    assert shop.totals(storage.get_user(e)["cart"])["shipping"] == 25
    order = shop.place_order(e)
    rec = storage.get_user(e)
    assert rec["cart"] == [] and rec["orders"][0]["id"] == order["id"] and order["total"] == 205
    expect(ValueError, shop.place_order, e)
    shop.save_sizes(e, {"upper_body": "L", "lower_body": "huge"})
    assert storage.get_user(e)["sizes"]["upper_body"] == "L" and storage.get_user(e)["sizes"]["lower_body"] is None
    folder = storage.user_upload_dir(e)
    (folder / "avatar.png").write_bytes(b"x")
    storage.rename_user(e, "new@example.com")
    assert (storage.user_upload_dir("new@example.com") / "avatar.png").exists()


def test_catalog():
    ps = all_products()
    assert len(ps) == 10 and all(p["price_sar"] > 0 and p["colors"] and p["category"] for p in ps)
    assert get_product("breton")["tag"] == "SAR 220" and "Knitwear" in categories()
    assert format_sar(1234) == "SAR 1,234"


def _png(w, h, color=(120, 120, 120)):
    buf = io.BytesIO()
    Image.new("RGB", (w, h), color).save(buf, format="PNG")
    return buf.getvalue()


def test_image_validation():
    assert validate_person_photo(b"not an image").accepted is False
    small = validate_person_photo(_png(200, 300))
    assert not small.accepted and small.errors
    ok = validate_person_photo(_png(600, 900))
    assert ok.accepted and "In focus" in ok.warnings   # flat colour = blurry -> warning only
    wide = validate_person_photo(_png(900, 600))
    assert wide.accepted and any("Portrait" in w for w in wide.warnings)


def test_model_is_pending_and_never_fakes():
    person, garment = Image.new("RGB", (600, 900)), Image.new("RGB", (400, 400))
    expect(IDMVTONNotIntegratedError, model_generate, person, garment, "upper_body")
    out = tryon_service.generate_tryon(person, garment, get_product("bone-tee"), "upper_body")
    assert out.status == "pending" and out.image is None and out.message == "IDM-VTON integration pending"
    assert tryon_service.is_model_ready() is False


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok ", name)
