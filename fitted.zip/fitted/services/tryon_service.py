"""
Bridge between the Streamlit UI and the model layer.

The UI never imports model internals directly. It calls:

    prepare_inputs(person, garment)  -> PreparedInputs   (real resize, no AI)
    generate_tryon(person, garment, product, category)  -> TryOnOutcome

While IDM-VTON is not integrated, `generate_tryon` returns
status="pending" with "IDM-VTON integration pending". It never returns the
input image or a placeholder as a result.
"""

from __future__ import annotations

import io
import urllib.request
from dataclasses import dataclass
from functools import lru_cache
from typing import Optional

from PIL import Image

from model.idm_vton import (
    GarmentCategory,
    IDMVTONNotIntegratedError,
    TryOnRequest,
    get_pipeline,
)
from model.idm_vton.config import DEFAULT_CONFIG
from model.idm_vton.preprocessing import prepare_garment, prepare_person

PENDING_MESSAGE = IDMVTONNotIntegratedError.USER_MESSAGE

CATEGORY_LABELS = {
    GarmentCategory.UPPER_BODY.value: "Upper body — tops, shirts, knitwear, jackets",
    GarmentCategory.LOWER_BODY.value: "Lower body — trousers, skirts, shorts",
    GarmentCategory.DRESSES.value: "Dresses — full-length pieces",
}


@dataclass
class TryOnOutcome:
    status: str                      # "ok" | "pending" | "error"
    message: str = ""
    image: Optional[Image.Image] = None
    detail: str = ""


@dataclass
class PreparedInputs:
    person: Image.Image
    garment: Optional[Image.Image]
    garment_error: str = ""


def model_status() -> str:
    return get_pipeline().status()


def is_model_ready() -> bool:
    return get_pipeline().is_available()


def default_category(product: dict) -> str:
    value = product.get("tryon_category", GarmentCategory.UPPER_BODY.value)
    return value if value in CATEGORY_LABELS else GarmentCategory.UPPER_BODY.value


@lru_cache(maxsize=32)
def _fetch(url: str) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "FITTED/1.0"})
    with urllib.request.urlopen(request, timeout=10) as response:
        return response.read()


def load_garment_image(product: dict) -> Image.Image:
    """Download the product photo (raises on network errors)."""
    image = Image.open(io.BytesIO(_fetch(product["image"])))
    image.load()
    return image


def prepare_inputs(person_image: Image.Image, product: dict) -> PreparedInputs:
    """Resize/pad both images to the IDM-VTON input size. No model involved."""
    person = prepare_person(person_image, DEFAULT_CONFIG)
    try:
        garment = prepare_garment(load_garment_image(product), DEFAULT_CONFIG)
        return PreparedInputs(person=person, garment=garment)
    except Exception as exc:  # network problems must not break the page
        return PreparedInputs(person=person, garment=None, garment_error=str(exc))


def generate_tryon(
    person_image: Image.Image,
    garment_image: Optional[Image.Image],
    product: dict,
    category: Optional[str] = None,
) -> TryOnOutcome:
    """Run a try-on, or report that the model is pending. Never raises."""
    pipeline = get_pipeline()
    if not pipeline.is_available():
        return TryOnOutcome(status="pending", message=PENDING_MESSAGE, detail=pipeline.status())
    if garment_image is None:
        return TryOnOutcome(status="error", message="The garment image could not be loaded.")

    request = TryOnRequest(
        person_image=person_image,
        garment_image=garment_image,
        garment_description=product.get("description") or product.get("name", ""),
        category=GarmentCategory(category or default_category(product)),
        garment_id=product.get("id"),
    )
    try:
        result = pipeline.run(request)
    except IDMVTONNotIntegratedError as exc:
        return TryOnOutcome(status="pending", message=PENDING_MESSAGE, detail=exc.detail)
    except Exception as exc:  # model errors must not crash the website
        return TryOnOutcome(status="error", message="Try-on failed.", detail=str(exc))
    return TryOnOutcome(status="ok", image=result.image)


__all__ = [
    "CATEGORY_LABELS", "PENDING_MESSAGE", "PreparedInputs", "TryOnOutcome",
    "default_category", "generate_tryon", "is_model_ready", "model_status", "prepare_inputs",
]
